module.exports = {
    apps: [
        {
            name: 'rome-tour-tickets',
            script: 'node_modules/next/dist/bin/next',
            args: 'start -p 3000', // Running on port 3000
            cwd: './',
            instances: 1,
            autorestart: true,
            watch: false,
            max_memory_restart: '1G',
            env: {
                NODE_ENV: 'production',
                PORT: 3000
            }
        }
    ]
};
