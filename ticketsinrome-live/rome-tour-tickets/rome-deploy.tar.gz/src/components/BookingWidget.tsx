'use client';

import { useState, useEffect, useMemo } from 'react';
import { Calendar, User, CheckCircle, Loader2, Info, Users, Clock, AlertTriangle, Star, Minus, Plus, ChevronRight, ShoppingCart } from 'lucide-react';
import { loadStripe, Stripe } from '@stripe/stripe-js';
import GuestDetailsModal, { GuestDetail } from './GuestDetailsModal';
import Image from 'next/image';
import SmartCalendar from './ui/SmartCalendar';
import { format } from 'date-fns';
import { useSite } from '@/components/SiteProvider';
import { useCart } from '@/context/CartContext';

// Site-specific Stripe publishable keys
const PUBLISHABLE_KEYS: Record<string, string> = {
    'rome-tour-tickets': process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY_ROME || process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '',
    'wondersofrome': process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY_WONDERS || process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '',
};

interface BookingWidgetProps {
    tour: {
        _id?: string;
        title: string;
        price: number;
        slug: { current: string }; // We need slug for API
        mainImage?: any;
        studentPrice?: number;
        youthPrice?: number;
        category?: string;
    };
}

interface TimeSlot {
    time: string;
    available_slots: number;
}

export default function BookingWidget({ tour }: BookingWidgetProps) {
    const site = useSite();
    const { addToCart } = useCart();
    const siteId = site?.slug?.current || process.env.NEXT_PUBLIC_SITE_ID || 'rome-tour-tickets';

    // Initialize Stripe with site-specific key
    const stripePromise = useMemo(() => {
        const key = PUBLISHABLE_KEYS[siteId] || PUBLISHABLE_KEYS['rome-tour-tickets'];
        if (!key) {
            console.error('Stripe publishable key not configured for site:', siteId);
            return null;
        }
        return loadStripe(key);
    }, [siteId]);

    // Ticket Counts
    const [adults, setAdults] = useState(1);
    const [students, setStudents] = useState(0);
    const [youths, setYouths] = useState(0);

    const [selectedDate, setSelectedDate] = useState('');
    const [selectedTime, setSelectedTime] = useState('');

    const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([]);
    const [loadingAvailability, setLoadingAvailability] = useState(false);

    // Checkout State
    const [checkingOut, setCheckingOut] = useState(false);
    const [showGuestModal, setShowGuestModal] = useState(false);
    const [guestDetails, setGuestDetails] = useState<GuestDetail[]>([]);

    // Derived State
    const totalGuests = adults + students + youths;
    const totalPrice = (adults * tour.price) +
        (students * (tour.studentPrice || tour.price)) +
        (youths * (tour.youthPrice || tour.price));

    const activeSlot = timeSlots.find(s => s.time === selectedTime);

    // Check availability when date changes
    useEffect(() => {
        if (!selectedDate) {
            setTimeSlots([]);
            return;
        }

        async function check() {
            setLoadingAvailability(true);
            setTimeSlots([]);
            setSelectedTime('');
            try {
                const res = await fetch(`/api/availability?slug=${tour.slug.current}&date=${selectedDate}`);
                const data = await res.json();
                setTimeSlots(data.slots || []);
            } catch (error) {
                console.error("Availability check failed", error);
            } finally {
                setLoadingAvailability(false);
            }
        }
        check();
    }, [selectedDate, tour.slug.current]);

    const handleAddToCart = () => {
        if (!selectedDate) {
            alert('Please select a date first');
            return;
        }
        if (!selectedTime) {
            alert('Please select a time');
            return;
        }

        const available = activeSlot?.available_slots || 0;
        if (available < totalGuests) {
            alert(`Sorry, only ${available} spots left for this time.`);
            return;
        }

        // Add to cart
        addToCart({
            id: `${tour._id || tour.slug.current}-${selectedDate}-${selectedTime}-${Date.now()}`,
            tourId: tour._id || tour.slug.current,
            tourTitle: tour.title,
            tourSlug: tour.slug.current,
            date: selectedDate,
            time: selectedTime,
            adults,
            students,
            youths,
            price: totalPrice,
            image: tour.mainImage ? urlFor(tour.mainImage).url() : undefined,
        });

        // Reset selection after adding to cart
        alert('Added to cart! You can continue shopping or proceed to checkout.');
    };

    const handleInitialClick = () => {
        if (!selectedDate) {
            alert('Please select a date first');
            return;
        }
        if (!selectedTime) {
            alert('Please select a time');
            return;
        }

        const available = activeSlot?.available_slots || 0;
        if (available < totalGuests) {
            alert(`Sorry, only ${available} spots left for this time.`);
            return;
        }

        // Always show modal to collect Customer Info (Lead Traveler)
        setShowGuestModal(true);
    };

    const handleGuestDetailsSubmit = (details: any) => {
        setGuestDetails(details);
        setShowGuestModal(false);
        processCheckout(details);
    };

    const processCheckout = async (details: any) => {
        // Redirect to custom checkout page with booking data
        const bookingData = {
            tour: {
                _id: tour._id,
                title: tour.title,
                slug: tour.slug,
                price: tour.price,
                studentPrice: tour.studentPrice,
                youthPrice: tour.youthPrice,
                mainImage: tour.mainImage,
                category: tour.category,
            },
            date: selectedDate,
            time: selectedTime,
            adults,
            students,
            youths,
            totalPrice,
            guestDetails: details,
        };

        // Encode booking data for URL
        const encodedData = encodeURIComponent(JSON.stringify(bookingData));
        window.location.href = `/checkout?data=${encodedData}`;
    };

    // Helper for Stepper
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const Stepper = ({ value, setValue, min = 0, max = 10 }: any) => (
        <div className="flex items-center gap-3">
            <button
                onClick={() => setValue(Math.max(min, value - 1))}
                disabled={value <= min}
                className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
                <Minus size={14} />
            </button>
            <span className="w-4 text-center font-bold text-gray-900">{value}</span>
            <button
                onClick={() => setValue(Math.min(max, value + 1))}
                disabled={value >= max}
                className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-emerald-600 hover:bg-emerald-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
                <Plus size={14} />
            </button>
        </div>
    );

    return (
        <div className="space-y-4">
            <div className="bg-white rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.08)] border border-gray-100/50 overflow-hidden">

                <GuestDetailsModal
                    isOpen={showGuestModal}
                    onClose={() => setShowGuestModal(false)}
                    onSubmit={handleGuestDetailsSubmit}
                    guestCounts={{ adults, students, youths }}
                />

                {/* Header: Title */}
                <div className="px-6 pt-6 pb-2">
                    <h3 className="text-xl font-black text-gray-900 flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-emerald-600" />
                        Select Dates
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">Select your preferred date to see availability.</p>
                </div>

                {/* Date & Time Selection */}
                <div className="p-6 space-y-6">
                    <div>
                        <SmartCalendar
                            slug={tour.slug.current}
                            selectedDate={selectedDate ? new Date(selectedDate) : undefined}
                            onSelect={(d) => setSelectedDate(d ? format(d, 'yyyy-MM-dd') : '')}
                            basePrice={tour.price}
                        />
                    </div>

                    {selectedDate && (
                        <div className="animate-in fade-in slide-in-from-top-2 duration-300 border-t border-gray-100 pt-6">
                            <div className="flex items-center gap-2 mb-3">
                                <Clock className="w-4 h-4 text-emerald-600" />
                                <span className="text-sm font-bold text-gray-900 uppercase tracking-wide">Select Time</span>
                            </div>

                            {loadingAvailability ? (
                                <div className="flex items-center justify-center py-8 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                                    <Loader2 className="w-5 h-5 animate-spin text-emerald-600 mr-2" />
                                    <span className="text-sm text-gray-500 font-medium">Checking available slots...</span>
                                </div>
                            ) : timeSlots.length > 0 ? (
                                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                    {timeSlots.map(slot => (
                                        <button
                                            key={slot.time}
                                            onClick={() => setSelectedTime(slot.time)}
                                            disabled={slot.available_slots === 0}
                                            className={`
                                                relative py-3 px-1 text-sm font-bold rounded-xl border transition-all duration-200 text-center
                                                ${selectedTime === slot.time
                                                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg shadow-emerald-200 scale-[1.02]'
                                                    : 'bg-white text-gray-700 border-gray-200 hover:border-emerald-500 hover:text-emerald-600 hover:shadow-sm'
                                                }
                                                ${slot.available_slots === 0 ? 'opacity-50 cursor-not-allowed bg-gray-50 text-gray-400' : ''}
                                            `}
                                        >
                                            {slot.time}
                                            {slot.available_slots < 5 && slot.available_slots > 0 &&
                                                <span className="absolute -top-2 -right-1 bg-rose-500 text-white text-[9px] px-1.5 py-0.5 rounded-full shadow-sm z-10">
                                                    {slot.available_slots} left
                                                </span>
                                            }
                                        </button>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-sm text-rose-600 font-bold py-3 px-4 bg-rose-50 rounded-xl border border-rose-100 flex items-center justify-center gap-2">
                                    <AlertTriangle size={16} />
                                    Sold Out for this date
                                </div>
                            )}
                        </div>
                    )}
                </div>

                {/* Guests Selection */}
                <div className="px-6 py-6 bg-gray-50/50 space-y-4 border-t border-gray-100">
                    <div className="flex items-center gap-2 mb-1">
                        <Users className="w-4 h-4 text-emerald-600" />
                        <span className="text-sm font-bold text-gray-900 uppercase tracking-wide">Participants</span>
                    </div>

                    {/* Adult */}
                    <div className="flex items-center justify-between">
                        <div>
                            <span className="block text-sm font-bold text-gray-900">Adult</span>
                            <span className="text-xs text-gray-500">Age 26+ • €{tour.price}</span>
                        </div>
                        <Stepper value={adults} setValue={setAdults} min={1} />
                    </div>

                    {/* Student */}
                    <div className="flex items-center justify-between">
                        <div>
                            <span className="block text-sm font-bold text-gray-900">Student</span>
                            <span className="text-[10px] text-orange-600 font-bold uppercase tracking-wide">ID Required</span>
                            <span className="text-xs text-gray-500">€{tour.studentPrice || tour.price}</span>
                        </div>
                        <Stepper value={students} setValue={setStudents} />
                    </div>

                    {/* Youth */}
                    <div className="flex items-center justify-between">
                        <div>
                            <span className="block text-sm font-bold text-gray-900">Youth</span>
                            <span className="text-[10px] text-orange-600 font-bold uppercase tracking-wide">Under 18</span>
                            <span className="text-xs text-gray-500">€{tour.youthPrice || tour.price}</span>
                        </div>
                        <Stepper value={youths} setValue={setYouths} />
                    </div>
                </div>

                {/* Footer Action - Sticky Style */}
                <div className="p-6 border-t border-gray-100 bg-white">
                    <div className="flex justify-between items-end mb-4">
                        <div>
                            <span className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Total Price</span>
                            <div className="flex items-baseline gap-1">
                                <span className="text-3xl font-black text-emerald-600 tracking-tight">€{totalPrice}</span>
                            </div>
                        </div>
                        {totalGuests > 0 && <span className="text-xs font-medium text-gray-400 mb-1">{totalGuests} participants</span>}
                    </div>

                    {/* Add to Cart Button */}
                    <button
                        onClick={handleAddToCart}
                        disabled={!selectedDate || !selectedTime || totalGuests === 0}
                        className={`w-full mb-3 py-3 rounded-xl font-bold text-base shadow-lg uppercase tracking-wide transition-all duration-300 transform active:scale-[0.98] flex items-center justify-center gap-2 ${
                            (!selectedDate || !selectedTime || totalGuests === 0) 
                                ? 'bg-gray-100 text-gray-400 cursor-not-allowed shadow-none' 
                                : 'bg-white border-2 border-emerald-600 text-emerald-600 hover:bg-emerald-50'
                        }`}
                    >
                        <ShoppingCart size={18} />
                        Add to Cart
                    </button>

                    <button
                        onClick={handleInitialClick}
                        disabled={checkingOut || !selectedDate || !selectedTime || totalGuests === 0}
                        className={`w-full py-4 rounded-xl font-black text-lg shadow-xl uppercase tracking-widest transition-all duration-300 transform active:scale-[0.98] ${checkingOut ? 'bg-gray-100 text-gray-400 cursor-not-allowed shadow-none' :
                            (!selectedDate || !selectedTime || totalGuests === 0) ? 'bg-gray-100 text-gray-400 cursor-not-allowed shadow-none' :
                                'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-200 hover:shadow-2xl hover:-translate-y-1'
                            }`}
                    >
                        {checkingOut ?
                            <span className="flex items-center justify-center gap-2"><Loader2 className="animate-spin" /> Processing</span> :
                            <span className="flex items-center justify-center gap-2">Book Now <ChevronRight size={20} /></span>
                        }
                    </button>

                    <div className="mt-4 flex items-center justify-center gap-4 text-[10px] font-medium text-gray-400 uppercase tracking-wider">
                        <span className="flex items-center gap-1"><CheckCircle size={12} className="text-emerald-500" /> Instant Confirmation</span>
                    </div>
                </div>

            </div>
        </div>
    );
}

// Import urlFor for images
import { urlFor } from '@/sanity/lib/image';
