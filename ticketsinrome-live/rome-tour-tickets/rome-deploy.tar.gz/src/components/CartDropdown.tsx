'use client';

import { useCart } from '@/context/CartContext';
import { ShoppingBag, X, Plus, Minus, Trash2 } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function CartDropdown() {
    const {
        items,
        removeFromCart,
        updateItem,
        totalItems,
        totalPrice,
        isCartOpen,
        setIsCartOpen
    } = useCart();
    const router = useRouter();

    const adjustGuests = (itemId: string, type: 'adults' | 'students' | 'youths', delta: number) => {
        const item = items.find(i => i.id === itemId);
        if (!item) return;

        const current = item[type];
        const newValue = Math.max(0, current + delta);

        // Calculate new price (simplified - you may want to fetch actual prices)
        const basePricePerPerson = item.price / (item.adults + item.students + item.youths || 1);
        const newTotalGuests = item.adults + item.students + item.youths + delta;
        const newPrice = basePricePerPerson * newTotalGuests;

        updateItem(itemId, {
            [type]: newValue,
            price: newPrice
        });
    };

    return (
        <div className="relative">
            {/* Cart Button */}
            <button
                onClick={() => setIsCartOpen(!isCartOpen)}
                className="relative p-2 rounded-full hover:bg-white/10 transition-colors"
                aria-label="Shopping cart"
            >
                <ShoppingBag className="w-5 h-5" />
                {totalItems > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-emerald-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                        {totalItems}
                    </span>
                )}
            </button>

            {/* Dropdown */}
            {isCartOpen && (
                <>
                    <div
                        className="fixed inset-0 z-40"
                        onClick={() => setIsCartOpen(false)}
                    />
                    <div className="absolute right-0 top-full mt-2 w-80 md:w-96 bg-white rounded-xl shadow-2xl border border-gray-100 z-50 overflow-hidden">
                        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                            <h3 className="font-bold text-gray-900">Your Cart ({totalItems})</h3>
                            <button
                                onClick={() => setIsCartOpen(false)}
                                className="p-1 hover:bg-gray-100 rounded-lg"
                            >
                                <X className="w-4 h-4" />
                            </button>
                        </div>

                        {items.length === 0 ? (
                            <div className="p-8 text-center">
                                <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                                <p className="text-gray-500 text-sm">Your cart is empty</p>
                                <Link
                                    href="/search"
                                    onClick={() => setIsCartOpen(false)}
                                    className="text-emerald-600 text-sm font-medium mt-2 inline-block"
                                >
                                    Browse tours
                                </Link>
                            </div>
                        ) : (
                            <>
                                <div className="max-h-80 overflow-y-auto">
                                    {items.map((item) => (
                                        <div key={item.id} className="p-4 border-b border-gray-100">
                                            <div className="flex gap-3">
                                                <div className="flex-1 min-w-0">
                                                    <h4 className="font-semibold text-gray-900 text-sm truncate">
                                                        {item.tourTitle}
                                                    </h4>
                                                    <p className="text-xs text-gray-500 mt-1">
                                                        {item.date} at {item.time}
                                                    </p>

                                                    {/* Guest Adjustments */}
                                                    <div className="mt-2 space-y-1">
                                                        {item.adults > 0 && (
                                                            <div className="flex items-center justify-between text-sm">
                                                                <span className="text-gray-600">Adults</span>
                                                                <div className="flex items-center gap-2">
                                                                    <button
                                                                        onClick={() => adjustGuests(item.id, 'adults', -1)}
                                                                        className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200"
                                                                    >
                                                                        <Minus className="w-3 h-3" />
                                                                    </button>
                                                                    <span className="w-6 text-center">{item.adults}</span>
                                                                    <button
                                                                        onClick={() => adjustGuests(item.id, 'adults', 1)}
                                                                        className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200"
                                                                    >
                                                                        <Plus className="w-3 h-3" />
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        )}
                                                        {item.students > 0 && (
                                                            <div className="flex items-center justify-between text-sm">
                                                                <span className="text-gray-600">Students</span>
                                                                <span className="text-gray-900">{item.students}</span>
                                                            </div>
                                                        )}
                                                        {item.youths > 0 && (
                                                            <div className="flex items-center justify-between text-sm">
                                                                <span className="text-gray-600">Youths</span>
                                                                <span className="text-gray-900">{item.youths}</span>
                                                            </div>
                                                        )}
                                                    </div>

                                                    <p className="text-emerald-600 font-bold text-sm mt-2">
                                                        €{item.price.toFixed(2)}
                                                    </p>
                                                </div>

                                                <button
                                                    onClick={() => removeFromCart(item.id)}
                                                    className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                <div className="p-4 bg-gray-50 border-t border-gray-100">
                                    <div className="flex items-center justify-between mb-3">
                                        <span className="font-semibold text-gray-900">Total</span>
                                        <span className="text-xl font-bold text-emerald-600">€{totalPrice.toFixed(2)}</span>
                                    </div>
                                    <button
                                        onClick={() => {
                                            setIsCartOpen(false);
                                            // Encode first cart item as booking data for checkout
                                            const item = items[0];
                                            if (item) {
                                                const bookingData = {
                                                    tour: {
                                                        _id: item.tourId,
                                                        title: item.tourTitle,
                                                        slug: { current: item.tourSlug },
                                                        price: item.price / Math.max(item.adults + item.students + item.youths, 1),
                                                    },
                                                    date: item.date,
                                                    time: item.time,
                                                    adults: item.adults,
                                                    students: item.students,
                                                    youths: item.youths,
                                                    totalPrice: item.price,
                                                };
                                                const encoded = encodeURIComponent(JSON.stringify(bookingData));
                                                router.push(`/checkout?data=${encoded}`);
                                            }
                                        }}
                                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl transition-colors"
                                    >
                                        Proceed to Checkout
                                    </button>
                                </div>
                            </>
                        )}
                    </div>
                </>
            )}
        </div>
    );
}
