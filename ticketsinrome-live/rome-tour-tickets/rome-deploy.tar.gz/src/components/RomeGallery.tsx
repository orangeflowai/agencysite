
'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';

const images = [
    'https://ogrvhooygcoazracbvkb.supabase.co/storage/v1/object/public/images/7a7a1aaf8a210f4c317ff7fa391e6738.jpg',
    'https://ogrvhooygcoazracbvkb.supabase.co/storage/v1/object/public/images/72be220be1e429973552a10c0b73b534.jpg',
    'https://ogrvhooygcoazracbvkb.supabase.co/storage/v1/object/public/images/5299212d395c8521d7c342332eaed823.jpg',
    'https://ogrvhooygcoazracbvkb.supabase.co/storage/v1/object/public/images/bad62cca-199f-4e71-91f1-e478ba8a1b29.jpg',
    'https://ogrvhooygcoazracbvkb.supabase.co/storage/v1/object/public/images/e5b1479b445c00ff11bbad9415d42a31.jpg',
];

export default function RomeGallery() {
    return (
        <section className="py-24 bg-neutral-900 border-t border-neutral-800 overflow-hidden relative">

            {/* Header */}
            <div className="container mx-auto px-4 mb-16 text-center relative z-10">
                <h2 className="text-4xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
                    Walk where the <span className="text-emerald-500">gladiators</span> walked
                </h2>
                <p className="text-gray-400 text-lg md:text-xl font-medium max-w-2xl mx-auto">
                    Immerse yourself in the eternal beauty of Rome. Every corner tells a story waiting to be discovered.
                </p>
            </div>

            {/* Marquee Container */}
            <div className="flex relative w-full">
                <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-neutral-900 to-transparent z-10"></div>
                <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-neutral-900 to-transparent z-10"></div>

                <motion.div
                    className="flex gap-6 whitespace-nowrap"
                    animate={{ x: [0, -1920] }} // Adjust based on total width approx
                    transition={{
                        repeat: Infinity,
                        ease: "linear",
                        duration: 40,
                    }}
                >
                    {/* Double the array for seamless loop */}
                    {[...images, ...images, ...images].map((src, i) => (
                        <div key={i} className="relative w-[300px] h-[400px] md:w-[400px] md:h-[500px] flex-shrink-0 rounded-2xl overflow-hidden grayscale hover:grayscale-0 transition-all duration-500 hover:scale-105">
                            <Image
                                src={src}
                                alt={`Rome Gallery ${i}`}
                                fill
                                className="object-cover"
                                sizes="(max-width: 768px) 300px, 400px"
                                quality={60}
                                loading="lazy"
                            />
                            <div className="absolute inset-0 bg-black/20 hover:bg-transparent transition-colors"></div>
                        </div>
                    ))}
                </motion.div>
            </div>
        </section>
    );
}
