'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export type Language = 'en' | 'it' | 'es' | 'fr' | 'de';

interface LanguageContextType {
    language: Language;
    setLanguage: (lang: Language) => void;
    t: (key: string) => string;
    translateTour: (tour: any) => TranslatedTour;
}

// Tour translations interface
export interface TranslatedTour {
    _id: string;
    title: string;
    description?: any;
    highlights?: string[];
    includes?: string[];
    excludes?: string[];
    meetingPoint?: string;
    importantInfo?: string[];
    itinerary?: Array<{ title: string; description: string; duration: string }>;
    faqs?: Array<{ question: string; answer: string }>;
    slug: { current: string };
    mainImage?: any;
    gallery?: any[];
    price: number;
    duration: string;
    category: string;
    badge?: string;
    rating?: number;
    reviewCount?: number;
    groupSize?: string;
    location?: string;
    tags?: string[];
    seoTitle?: string;
    seoDescription?: string;
    // Raw translations object
    translations?: Record<string, any>;
}

const translations = {
    en: {
        // Navigation
        'nav.colosseum': 'Colosseum Tours',
        'nav.vatican': 'Vatican Tours',
        'nav.city': 'City Tours',
        'nav.hidden': 'Hidden Gems',
        'nav.search_placeholder': 'Search tours...',
        'nav.menu': 'Menu',
        'nav.search': 'Search',
        
        // Hero
        'hero.title': 'Rome, Curated.',
        'hero.subtitle': 'Experience the Eternal City with expert local guides.',
        'hero.cta': 'Explore Tours',
        'hero.trust': 'Trusted by 50,000+ travelers',
        
        // Categories
        'cat.colosseum_title': 'Colosseum & Ancient Rome',
        'cat.colosseum_subtitle': 'Walk in the footsteps of Gladiators. Arena, Underground, and Forum.',
        'cat.vatican_title': 'Vatican Museums & St. Peter\'s',
        'cat.vatican_subtitle': 'Skip the line to the Sistine Chapel, Gardens, and the Dome.',
        'cat.city_title': 'Rome City Tours',
        'cat.city_subtitle': 'Explore the Pantheon, Trevi Fountain, Spanish Steps and iconic squares.',
        'cat.hidden_title': 'Italy Hidden Gems',
        'cat.hidden_subtitle': 'Catacombs, Golf Cart tours, Day trips, Food tours & unique experiences.',
        'cat.view_all': 'View All',
        
        // Footer
        'footer.about': 'Your gateway to the Eternal City. Experience Rome with our expert guides, skip-the-line access, and unforgettable customized journeys.',
        'footer.explore': 'Explore',
        'footer.support': 'Support',
        'footer.contact': 'Contact',
        'footer.colosseum': 'Colosseum Tours',
        'footer.vatican': 'Vatican Museums',
        'footer.city': 'City Tours',
        'footer.hidden': 'Hidden Gems',
        'footer.blog': 'Travel Blog',
        'footer.all_tours': 'All Tours',
        'footer.contact_us': 'Contact Us',
        'footer.faq': 'FAQ',
        'footer.terms': 'Terms & Conditions',
        'footer.privacy': 'Privacy Policy',
        'footer.cancellation': 'Cancellation Policy',
        'footer.disclaimer': 'Disclaimer',
        'footer.partner': 'Become a Partner',
        'footer.address': 'Via Tunisi 43, Rome, Italy',
        'footer.rights': 'All rights reserved.',
        
        // Contact Page
        'contact.title': 'Contact Us',
        'contact.subtitle': 'Have questions? Our local team is here to help.',
        'contact.form.name': 'First Name',
        'contact.form.email': 'Email Address',
        'contact.form.message': 'Message',
        'contact.form.send': 'Send Message',
        'contact.form.sending': 'Sending...',
        'contact.success': 'Thank you! We will get back to you soon.',
        'contact.error': 'Something went wrong. Please try again.',
        
        // Tour Page
        'tour.overview': 'Tour Overview',
        'tour.highlights': 'Highlights',
        'tour.itinerary': 'Itinerary',
        'tour.includes': 'What\'s Included',
        'tour.excludes': 'What\'s Not Included',
        'tour.meeting': 'Meeting Point',
        'tour.important': 'Important Information',
        'tour.book_now': 'Book Now',
        'tour.from': 'From',
        'tour.per_person': 'per person',
        'tour.select_date': 'Select Date',
        'tour.guests': 'Guests',
        'tour.duration': 'Duration',
        'tour.group_size': 'Group Size',
        'tour.reviews': 'reviews',
        'tour.not_available': 'Not Available',
        
        // Booking
        'booking.select_time': 'Select Time',
        'booking.checkout': 'Proceed to Checkout',
        'booking.total': 'Total',
        'booking.processing': 'Processing...',
        'booking.addons_title': 'Enhance Your Experience',
        'booking.addons_subtitle': 'Optional add-ons to make your tour even better',
        
        // Common
        'common.loading': 'Loading...',
        'common.read_more': 'Read More',
        'common.learn_more': 'Learn More',
        'common.next': 'Next',
        'common.prev': 'Previous',
        'common.close': 'Close',
        'common.open': 'Open',
        'common.yes': 'Yes',
        'common.no': 'No',
        'common.translated_by_google': 'Translated by Google',
    },
    it: {
        // Navigation
        'nav.colosseum': 'Tour del Colosseo',
        'nav.vatican': 'Tour del Vaticano',
        'nav.city': 'Tour della Città',
        'nav.hidden': 'Gemme Nascoste',
        'nav.search_placeholder': 'Cerca tour...',
        'nav.menu': 'Menu',
        'nav.search': 'Cerca',
        
        // Hero
        'hero.title': 'Roma, Curata.',
        'hero.subtitle': 'Vivi la Città Eterna con guide locali esperte.',
        'hero.cta': 'Esplora i Tour',
        'hero.trust': 'Scelto da oltre 50.000 viaggiatori',
        
        // Categories
        'cat.colosseum_title': 'Colosseo e Roma Antica',
        'cat.colosseum_subtitle': 'Cammina sulle orme dei gladiatori. Arena, Sotterranei e Foro.',
        'cat.vatican_title': 'Musei Vaticani e San Pietro',
        'cat.vatican_subtitle': 'Salta la fila per la Cappella Sistina, i Giardini e la Cupola.',
        'cat.city_title': 'Tour di Roma',
        'cat.city_subtitle': 'Esplora il Pantheon, Fontana di Trevi, Piazza di Spagna e le piazze iconiche.',
        'cat.hidden_title': 'Gioielli Nascosti d\'Italia',
        'cat.hidden_subtitle': 'Catacombe, tour in Golf Cart, gite fuori porta, tour enogastronomici.',
        'cat.view_all': 'Vedi Tutti',
        
        // Footer
        'footer.about': 'La tua porta d\'accesso alla Città Eterna. Vivi Roma con le nostre guide esperte, accesso salta-fila e viaggi indimenticabili.',
        'footer.explore': 'Esplora',
        'footer.support': 'Supporto',
        'footer.contact': 'Contatti',
        'footer.colosseum': 'Tour del Colosseo',
        'footer.vatican': 'Musei Vaticani',
        'footer.city': 'Tour della Città',
        'footer.hidden': 'Gemme Nascoste',
        'footer.blog': 'Blog di Viaggio',
        'footer.all_tours': 'Tutti i Tour',
        'footer.contact_us': 'Contattaci',
        'footer.faq': 'FAQ',
        'footer.terms': 'Termini e Condizioni',
        'footer.privacy': 'Privacy Policy',
        'footer.cancellation': 'Politica di Cancellazione',
        'footer.disclaimer': 'Disclaimer',
        'footer.partner': 'Diventa Partner',
        'footer.address': 'Via Tunisi 43, Roma, Italia',
        'footer.rights': 'Tutti i diritti riservati.',
        
        // Contact Page
        'contact.title': 'Contattaci',
        'contact.subtitle': 'Hai domande? Il nostro team locale è qui per aiutarti.',
        'contact.form.name': 'Nome',
        'contact.form.email': 'Indirizzo Email',
        'contact.form.message': 'Messaggio',
        'contact.form.send': 'Invia Messaggio',
        'contact.form.sending': 'Invio in corso...',
        'contact.success': 'Grazie! Ti risponderemo presto.',
        'contact.error': 'Qualcosa è andato storto. Riprova.',
        
        // Tour Page
        'tour.overview': 'Panoramica del Tour',
        'tour.highlights': 'Highlights',
        'tour.itinerary': 'Itinerario',
        'tour.includes': 'Cosa è Incluso',
        'tour.excludes': 'Cosa non è Incluso',
        'tour.meeting': 'Punto di Incontro',
        'tour.important': 'Informazioni Importanti',
        'tour.book_now': 'Prenota Ora',
        'tour.from': 'Da',
        'tour.per_person': 'a persona',
        'tour.select_date': 'Seleziona Data',
        'tour.guests': 'Ospiti',
        'tour.duration': 'Durata',
        'tour.group_size': 'Dimensione Gruppo',
        'tour.reviews': 'recensioni',
        'tour.not_available': 'Non Disponibile',
        
        // Booking
        'booking.select_time': 'Seleziona Orario',
        'booking.checkout': 'Procedi al Pagamento',
        'booking.total': 'Totale',
        'booking.processing': 'Elaborazione...',
        'booking.addons_title': 'Migliora la tua Esperienza',
        'booking.addons_subtitle': 'Optional per rendere il tuo tour ancora migliore',
        
        // Common
        'common.loading': 'Caricamento...',
        'common.read_more': 'Leggi di più',
        'common.learn_more': 'Scopri di più',
        'common.next': 'Successivo',
        'common.prev': 'Precedente',
        'common.close': 'Chiudi',
        'common.open': 'Apri',
        'common.yes': 'Sì',
        'common.no': 'No',
        'common.translated_by_google': 'Tradotto da Google',
    },
    es: {
        // Navigation
        'nav.colosseum': 'Tours del Coliseo',
        'nav.vatican': 'Tours del Vaticano',
        'nav.city': 'Tours por la Ciudad',
        'nav.hidden': 'Joyas Ocultas',
        'nav.search_placeholder': 'Buscar tours...',
        'nav.menu': 'Menú',
        'nav.search': 'Buscar',
        
        // Hero
        'hero.title': 'Roma, Curada.',
        'hero.subtitle': 'Experimenta la Ciudad Eterna con guías locales expertos.',
        'hero.cta': 'Explorar Tours',
        'hero.trust': 'Elegido por más de 50,000 viajeros',
        
        // Categories
        'cat.colosseum_title': 'Coliseo y Roma Antigua',
        'cat.colosseum_subtitle': 'Camina sobre los pasos de los gladiadores. Arena, Subterráneo y Foro.',
        'cat.vatican_title': 'Museos Vaticanos y San Pedro',
        'cat.vatican_subtitle': 'Salta la fila para la Capilla Sixtina, Jardines y la Cúpula.',
        'cat.city_title': 'Tours por Roma',
        'cat.city_subtitle': 'Explora el Panteón, Fontana di Trevi, Plaza de España y plazas icónicas.',
        'cat.hidden_title': 'Joyas Ocultas de Italia',
        'cat.hidden_subtitle': 'Catacumbas, tours en Golf Cart, excursiones, tours gastronómicos.',
        'cat.view_all': 'Ver Todos',
        
        // Footer
        'footer.about': 'Tu puerta de entrada a la Ciudad Eterna. Experimenta Roma con nuestros guías expertos.',
        'footer.explore': 'Explorar',
        'footer.support': 'Soporte',
        'footer.contact': 'Contacto',
        'footer.colosseum': 'Tours del Coliseo',
        'footer.vatican': 'Museos Vaticanos',
        'footer.city': 'Tours por la Ciudad',
        'footer.hidden': 'Joyas Ocultas',
        'footer.blog': 'Blog de Viaje',
        'footer.all_tours': 'Todos los Tours',
        'footer.contact_us': 'Contáctanos',
        'footer.faq': 'Preguntas Frecuentes',
        'footer.terms': 'Términos y Condiciones',
        'footer.privacy': 'Política de Privacidad',
        'footer.cancellation': 'Política de Cancelación',
        'footer.disclaimer': 'Aviso Legal',
        'footer.partner': 'Conviértete en Partner',
        'footer.address': 'Via Tunisi 43, Roma, Italia',
        'footer.rights': 'Todos los derechos reservados.',
        
        // Contact Page
        'contact.title': 'Contáctanos',
        'contact.subtitle': '¿Tienes preguntas? Nuestro equipo local está aquí para ayudarte.',
        'contact.form.name': 'Nombre',
        'contact.form.email': 'Correo Electrónico',
        'contact.form.message': 'Mensaje',
        'contact.form.send': 'Enviar Mensaje',
        'contact.form.sending': 'Enviando...',
        'contact.success': '¡Gracias! Te responderemos pronto.',
        'contact.error': 'Algo salió mal. Por favor, inténtalo de nuevo.',
        
        // Tour Page
        'tour.overview': 'Descripción del Tour',
        'tour.highlights': 'Puntos Destacados',
        'tour.itinerary': 'Itinerario',
        'tour.includes': 'Qué está Incluido',
        'tour.excludes': 'Qué no está Incluido',
        'tour.meeting': 'Punto de Encuentro',
        'tour.important': 'Información Importante',
        'tour.book_now': 'Reservar Ahora',
        'tour.from': 'Desde',
        'tour.per_person': 'por persona',
        'tour.select_date': 'Seleccionar Fecha',
        'tour.guests': 'Huéspedes',
        'tour.duration': 'Duración',
        'tour.group_size': 'Tamaño del Grupo',
        'tour.reviews': 'reseñas',
        'tour.not_available': 'No Disponible',
        
        // Booking
        'booking.select_time': 'Seleccionar Hora',
        'booking.checkout': 'Proceder al Pago',
        'booking.total': 'Total',
        'booking.processing': 'Procesando...',
        'booking.addons_title': 'Mejora tu Experiencia',
        'booking.addons_subtitle': 'Complementos opcionales para mejorar tu tour',
        
        // Common
        'common.loading': 'Cargando...',
        'common.read_more': 'Leer más',
        'common.learn_more': 'Más información',
        'common.next': 'Siguiente',
        'common.prev': 'Anterior',
        'common.close': 'Cerrar',
        'common.open': 'Abrir',
        'common.yes': 'Sí',
        'common.no': 'No',
        'common.translated_by_google': 'Traducido por Google',
    },
    fr: {
        // Navigation
        'nav.colosseum': 'Visites du Colisée',
        'nav.vatican': 'Visites du Vatican',
        'nav.city': 'Visites de la Ville',
        'nav.hidden': 'Trésors Cachés',
        'nav.search_placeholder': 'Rechercher...',
        'nav.menu': 'Menu',
        'nav.search': 'Rechercher',
        
        // Hero
        'hero.title': 'Rome, Soignée.',
        'hero.subtitle': 'Découvrez la Ville Éternelle avec des guides locaux experts.',
        'hero.cta': 'Explorer les Visites',
        'hero.trust': 'Choisi par plus de 50 000 voyageurs',
        
        // Categories
        'cat.colosseum_title': 'Colisée et Rome Antique',
        'cat.colosseum_subtitle': 'Marchez sur les traces des gladiateurs. Arène, Souterrains et Forum.',
        'cat.vatican_title': 'Musées du Vatican et Saint-Pierre',
        'cat.vatican_subtitle': 'Coupe-file pour la Chapelle Sixtine, les Jardins et le Dôme.',
        'cat.city_title': 'Visites de Rome',
        'cat.city_subtitle': 'Explorez le Panthéon, la Fontaine de Trevi, la Place d\'Espagne.',
        'cat.hidden_title': 'Trésors Cachés d\'Italie',
        'cat.hidden_subtitle': 'Catacombes, tours en Golf Cart, excursions, tours gastronomiques.',
        'cat.view_all': 'Voir Tout',
        
        // Footer
        'footer.about': 'Votre porte d\'entrée vers la Ville Éternelle. Découvrez Rome avec nos guides experts.',
        'footer.explore': 'Explorer',
        'footer.support': 'Support',
        'footer.contact': 'Contact',
        'footer.colosseum': 'Visites du Colisée',
        'footer.vatican': 'Musées du Vatican',
        'footer.city': 'Visites de la Ville',
        'footer.hidden': 'Trésors Cachés',
        'footer.blog': 'Blog Voyage',
        'footer.all_tours': 'Tous les Tours',
        'footer.contact_us': 'Contactez-nous',
        'footer.faq': 'FAQ',
        'footer.terms': 'Conditions Générales',
        'footer.privacy': 'Politique de Confidentialité',
        'footer.cancellation': 'Politique d\'Annulation',
        'footer.disclaimer': 'Mentions Légales',
        'footer.partner': 'Devenir Partenaire',
        'footer.address': 'Via Tunisi 43, Rome, Italie',
        'footer.rights': 'Tous droits réservés.',
        
        // Contact Page
        'contact.title': 'Contactez-nous',
        'contact.subtitle': 'Des questions ? Notre équipe locale est là pour vous aider.',
        'contact.form.name': 'Prénom',
        'contact.form.email': 'Adresse E-mail',
        'contact.form.message': 'Message',
        'contact.form.send': 'Envoyer le message',
        'contact.form.sending': 'Envoi en cours...',
        'contact.success': 'Merci ! Nous vous répondrons bientôt.',
        'contact.error': 'Une erreur s\'est produite. Veuillez réessayer.',
        
        // Tour Page
        'tour.overview': 'Aperçu de la Visite',
        'tour.highlights': 'Points Forts',
        'tour.itinerary': 'Itinéraire',
        'tour.includes': 'Ce qui est Inclus',
        'tour.excludes': 'Ce qui n\'est pas Inclus',
        'tour.meeting': 'Point de Rendez-vous',
        'tour.important': 'Informations Importantes',
        'tour.book_now': 'Réserver Maintenant',
        'tour.from': 'À partir de',
        'tour.per_person': 'par personne',
        'tour.select_date': 'Sélectionner une Date',
        'tour.guests': 'Invités',
        'tour.duration': 'Durée',
        'tour.group_size': 'Taille du Groupe',
        'tour.reviews': 'avis',
        'tour.not_available': 'Non Disponible',
        
        // Booking
        'booking.select_time': 'Sélectionner l\'Heure',
        'booking.checkout': 'Procéder au Paiement',
        'booking.total': 'Total',
        'booking.processing': 'Traitement...',
        'booking.addons_title': 'Améliorez Votre Expérience',
        'booking.addons_subtitle': 'Options supplémentaires pour améliorer votre visite',
        
        // Common
        'common.loading': 'Chargement...',
        'common.read_more': 'Lire la suite',
        'common.learn_more': 'En savoir plus',
        'common.next': 'Suivant',
        'common.prev': 'Précédent',
        'common.close': 'Fermer',
        'common.open': 'Ouvrir',
        'common.yes': 'Oui',
        'common.no': 'Non',
        'common.translated_by_google': 'Traduit par Google',
    },
    de: {
        // Navigation
        'nav.colosseum': 'Kolosseum Touren',
        'nav.vatican': 'Vatikan Touren',
        'nav.city': 'Stadttouren',
        'nav.hidden': 'Versteckte Schätze',
        'nav.search_placeholder': 'Touren suchen...',
        'nav.menu': 'Menü',
        'nav.search': 'Suchen',
        
        // Hero
        'hero.title': 'Rom, Kuratiert.',
        'hero.subtitle': 'Erleben Sie die Ewige Stadt mit erfahrenen lokalen Guides.',
        'hero.cta': 'Touren Entdecken',
        'hero.trust': 'Von über 50.000 Reisenden gewählt',
        
        // Categories
        'cat.colosseum_title': 'Kolosseum & Antikes Rom',
        'cat.colosseum_subtitle': 'Gehen Sie auf den Spuren der Gladiatoren. Arena, Untergeschoss und Forum.',
        'cat.vatican_title': 'Vatikanische Museen & St. Peter',
        'cat.vatican_subtitle': 'Skip-the-line für die Sixtinische Kapelle, Gärten und Kuppel.',
        'cat.city_title': 'Rom Stadttouren',
        'cat.city_subtitle': 'Erkunden Sie das Pantheon, Trevi-Brunnen, Spanische Treppe.',
        'cat.hidden_title': 'Versteckte Schätze Italiens',
        'cat.hidden_subtitle': 'Katakomben, Golf Cart Touren, Tagesausflüge, Food Tours.',
        'cat.view_all': 'Alle Ansehen',
        
        // Footer
        'footer.about': 'Ihr Tor zur Ewigen Stadt. Erleben Sie Rom mit unseren erfahrenen Guides.',
        'footer.explore': 'Entdecken',
        'footer.support': 'Support',
        'footer.contact': 'Kontakt',
        'footer.colosseum': 'Kolosseum Touren',
        'footer.vatican': 'Vatikanische Museen',
        'footer.city': 'Stadttouren',
        'footer.hidden': 'Versteckte Schätze',
        'footer.blog': 'Reiseblog',
        'footer.all_tours': 'Alle Touren',
        'footer.contact_us': 'Kontaktiere Uns',
        'footer.faq': 'FAQ',
        'footer.terms': 'AGB',
        'footer.privacy': 'Datenschutz',
        'footer.cancellation': 'Stornierungsbedingungen',
        'footer.disclaimer': 'Impressum',
        'footer.partner': 'Partner Werden',
        'footer.address': 'Via Tunisi 43, Rom, Italien',
        'footer.rights': 'Alle Rechte vorbehalten.',
        
        // Contact Page
        'contact.title': 'Kontaktiere Uns',
        'contact.subtitle': 'Haben Sie Fragen? Unser lokales Team hilft Ihnen gerne.',
        'contact.form.name': 'Vorname',
        'contact.form.email': 'E-Mail Adresse',
        'contact.form.message': 'Nachricht',
        'contact.form.send': 'Nachricht Senden',
        'contact.form.sending': 'Wird gesendet...',
        'contact.success': 'Danke! Wir melden uns bald bei Ihnen.',
        'contact.error': 'Etwas ist schiefgelaufen. Bitte versuchen Sie es erneut.',
        
        // Tour Page
        'tour.overview': 'Tour Übersicht',
        'tour.highlights': 'Höhepunkte',
        'tour.itinerary': 'Reiseroute',
        'tour.includes': 'Inklusive',
        'tour.excludes': 'Nicht Inklusive',
        'tour.meeting': 'Treffpunkt',
        'tour.important': 'Wichtige Informationen',
        'tour.book_now': 'Jetzt Buchen',
        'tour.from': 'Ab',
        'tour.per_person': 'pro Person',
        'tour.select_date': 'Datum Wählen',
        'tour.guests': 'Gäste',
        'tour.duration': 'Dauer',
        'tour.group_size': 'Gruppengröße',
        'tour.reviews': 'Bewertungen',
        'tour.not_available': 'Nicht Verfügbar',
        
        // Booking
        'booking.select_time': 'Uhrzeit Wählen',
        'booking.checkout': 'Zur Kasse',
        'booking.total': 'Gesamt',
        'booking.processing': 'Wird verarbeitet...',
        'booking.addons_title': 'Verbessern Sie Ihr Erlebnis',
        'booking.addons_subtitle': 'Optionale Zusätze für ein besseres Tour-Erlebnis',
        
        // Common
        'common.loading': 'Laden...',
        'common.read_more': 'Mehr Lesen',
        'common.learn_more': 'Mehr Erfahren',
        'common.next': 'Weiter',
        'common.prev': 'Zurück',
        'common.close': 'Schließen',
        'common.open': 'Öffnen',
        'common.yes': 'Ja',
        'common.no': 'Nein',
        'common.translated_by_google': 'Übersetzt von Google',
    }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
    const [language, setLanguageState] = useState<Language>('en');
    const [isHydrated, setIsHydrated] = useState(false);

    useEffect(() => {
        setIsHydrated(true);
        const saved = localStorage.getItem('ticketsinrome-lang') as Language;
        if (saved && ['en', 'it', 'es', 'fr', 'de'].includes(saved)) {
            setLanguageState(saved);
            // Also trigger Google Translate
            triggerGoogleTranslate(saved);
        }
    }, []);

    // Trigger Google Translate
    const triggerGoogleTranslate = (lang: string) => {
        if (typeof window !== 'undefined' && lang !== 'en') {
            // Small delay to ensure Google Translate is loaded
            setTimeout(() => {
                const googleTranslateDropdown = document.querySelector('.goog-te-combo') as HTMLSelectElement;
                if (googleTranslateDropdown) {
                    googleTranslateDropdown.value = lang;
                    googleTranslateDropdown.dispatchEvent(new Event('change'));
                }
            }, 500);
        }
    };

    const setLanguage = (lang: Language) => {
        setLanguageState(lang);
        localStorage.setItem('ticketsinrome-lang', lang);
        
        // Dispatch event for other components
        window.dispatchEvent(new CustomEvent('languagechange', { detail: lang }));
        
        // Trigger Google Translate
        triggerGoogleTranslate(lang);
        
        // Update html lang attribute
        document.documentElement.lang = lang;
    };

    // Translation function for UI strings
    const t = (key: string): string => {
        const translation = (translations[language] as Record<string, string>)?.[key];
        if (!translation) {
            // Fallback to English
            return (translations['en'] as Record<string, string>)?.[key] || key;
        }
        return translation;
    };

    // Helper to get translated tour data
    const translateTour = useCallback((tour: any): TranslatedTour => {
        if (!tour) return tour;
        
        const lang = language;
        
        // If English or no translations available, return original
        if (lang === 'en' || !tour.translations) {
            return {
                ...tour,
                title: tour.title,
                description: tour.description,
                highlights: tour.highlights || [],
                includes: tour.includes || [],
                excludes: tour.excludes || [],
                meetingPoint: tour.meetingPoint,
                importantInfo: tour.importantInfo || [],
                itinerary: tour.itinerary || [],
                faqs: tour.faqs || [],
            };
        }

        // Get translations for current language
        const trans = tour.translations[lang];
        
        return {
            ...tour,
            title: trans?.title || tour.title,
            description: trans?.description || tour.description,
            highlights: trans?.highlights || tour.highlights || [],
            includes: trans?.includes || tour.includes || [],
            excludes: trans?.excludes || tour.excludes || [],
            meetingPoint: trans?.meetingPoint || tour.meetingPoint,
            importantInfo: trans?.importantInfo || tour.importantInfo || [],
            itinerary: trans?.itinerary || tour.itinerary || [],
            faqs: trans?.faqs || tour.faqs || [],
            seoTitle: trans?.seoTitle || tour.seoTitle,
            seoDescription: trans?.seoDescription || tour.seoDescription,
            translations: tour.translations,
        };
    }, [language]);

    // Prevent hydration mismatch
    if (!isHydrated) {
        return (
            <LanguageContext.Provider 
                value={{ 
                    language: 'en', 
                    setLanguage: () => {}, 
                    t: (k) => (translations['en'] as Record<string, string>)?.[k] || k,
                    translateTour: (t) => t,
                }}
            >
                {children}
            </LanguageContext.Provider>
        );
    }

    return (
        <LanguageContext.Provider value={{ language, setLanguage, t, translateTour }}>
            {children}
        </LanguageContext.Provider>
    );
}

export function useLanguage() {
    const context = useContext(LanguageContext);
    if (context === undefined) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
}

// Helper hook for tour translations
export function useTranslatedTour(tour: any) {
    const { translateTour } = useLanguage();
    return translateTour(tour);
}
