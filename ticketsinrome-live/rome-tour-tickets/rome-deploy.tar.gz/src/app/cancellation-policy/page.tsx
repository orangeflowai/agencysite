
import React from 'react';
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Link from 'next/link';
import type { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'Cancellation & Refund Policy | TicketsInRome',
    description: 'Cancellation and Refund Policy for TicketsInRome bookings.',
};

export default function CancellationPolicy() {
    return (
        <main className="min-h-screen bg-cream selection:bg-olive selection:text-white">
            <Navbar />

            <div className="container mx-auto px-4 py-24 max-w-4xl">
                <h1 className="text-4xl md:text-5xl font-black text-gray-900 mb-8 tracking-tight">Cancellation & Refund Policy</h1>

                <div className="prose prose-lg prose-emerald text-gray-600 max-w-none space-y-8">
                    <p className="lead text-xl text-gray-800 font-medium">
                        At Tickets in Rome, we understand that travel plans can change. This policy outlines the conditions under which you may cancel your bookings and your eligibility for refunds.
                    </p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">1. General Cancellation Rules</h3>
                    <p>
                        All cancellation requests must be submitted in writing via email to <a href="mailto:support@ticketsinrome.com" className="text-emerald-700 font-bold hover:underline">support@ticketsinrome.com</a> or by contacting our customer service line at <a href="tel:+393514199425" className="text-emerald-700 font-bold hover:underline">+39 351 419 9425</a>. The timing of your request is calculated based on the local time in Rome, Italy.
                    </p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">2. Refund Eligibility Tiers</h3>
                    <p>Unless otherwise stated on the specific tour page, the following standard cancellation fees apply to all Tickets in Rome bookings:</p>

                    <div className="overflow-x-auto my-8 border border-gray-200 rounded-xl shadow-sm">
                        <table className="min-w-full bg-white text-left text-sm md:text-base">
                            <thead className="bg-emerald-900 text-white">
                                <tr>
                                    <th className="py-4 px-6 font-bold uppercase tracking-wider w-1/2">Time of Cancellation</th>
                                    <th className="py-4 px-6 font-bold uppercase tracking-wider w-1/2">Refund Amount</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                <tr className="hover:bg-gray-50 transition-colors">
                                    <td className="py-4 px-6 font-medium text-gray-900">More than 7 days before the tour</td>
                                    <td className="py-4 px-6 text-emerald-700 font-bold">100% Refund <span className="text-gray-500 font-normal text-sm ml-1">(minus non-refundable fees)</span></td>
                                </tr>
                                <tr className="hover:bg-gray-50 transition-colors">
                                    <td className="py-4 px-6 font-medium text-gray-900">Between 3 to 7 days before the tour</td>
                                    <td className="py-4 px-6 text-yellow-600 font-bold">50% Refund</td>
                                </tr>
                                <tr className="hover:bg-gray-50 transition-colors">
                                    <td className="py-4 px-6 font-medium text-gray-900">Less than 72 hours before the tour</td>
                                    <td className="py-4 px-6 text-red-600 font-bold">No Refund (0%)</td>
                                </tr>
                                <tr className="hover:bg-gray-50 transition-colors">
                                    <td className="py-4 px-6 font-medium text-gray-900">"No Show" on the day of the tour</td>
                                    <td className="py-4 px-6 text-red-600 font-bold">No Refund (0%)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div className="bg-amber-50 border-l-4 border-amber-400 p-6 my-6 rounded-r-lg">
                        <p className="font-bold text-amber-900 mb-2">Note on Non-Refundable Fees:</p>
                        <p className="text-amber-800 text-sm leading-relaxed">
                            Many Roman sites (such as the Colosseum and Vatican Museums) issue tickets that are non-refundable and non-transferable immediately upon purchase. In these cases, the cost of the entrance ticket will be deducted from your refund regardless of when you cancel.
                        </p>
                    </div>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">3. Rescheduling</h3>
                    <p>If you wish to change the date or time of your tour, Tickets in Rome will do its best to accommodate your request subject to availability.</p>
                    <ul className="list-disc pl-5 space-y-2">
                        <li><strong>More than 72 hours in advance:</strong> Usually free of charge, excluding any new ticket costs.</li>
                        <li><strong>Within 72 hours:</strong> May be treated as a cancellation and a new booking.</li>
                    </ul>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">4. Cancellations by Tickets in Rome</h3>
                    <p>On rare occasions, Tickets in Rome may need to cancel a tour due to:</p>
                    <ul className="list-disc pl-5 space-y-1">
                        <li>Extreme weather conditions.</li>
                        <li>Unexpected closures of sites/monuments by the authorities.</li>
                        <li>Strikes or labor disputes.</li>
                    </ul>
                    <p>In the event that we cancel your tour, you will be offered the choice of an <strong>alternative date or a full 100% refund</strong>.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">5. Punctuality & Late Arrivals</h3>
                    <p>Tours in Rome operate on a strict schedule. If you arrive late for your meeting time, the tour may start without you to respect the experience of other guests. Tickets in Rome is not responsible for missed tours due to late arrival, and no refunds will be issued in these instances.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">6. Processing of Refunds</h3>
                    <p>Once approved, refunds are processed back to the original payment method used during booking. Please allow <strong>5 to 10 business days</strong> for the funds to appear in your account, depending on your bank's processing times.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">7. Contact Us</h3>
                    <p>For all cancellation and refund inquiries, please reach out to:</p>
                    <ul className="list-none pl-0 space-y-2">
                        <li><strong>Email:</strong> <a href="mailto:support@ticketsinrome.com" className="text-emerald-700 font-bold hover:underline">support@ticketsinrome.com</a></li>
                        <li><strong>Website:</strong> <Link href="/contact" className="text-emerald-700 font-bold hover:underline">https://ticketsinrome.com/contact/</Link></li>
                        <li><strong>Phone/WhatsApp:</strong> <a href="tel:+393514199425" className="text-emerald-700 font-bold hover:underline">+39 351 419 9425</a></li>
                    </ul>
                </div>
            </div>

            <Footer />
        </main>
    );
}
