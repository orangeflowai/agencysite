
import React from 'react';
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import type { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'Terms and Conditions | TicketsInRome',
    description: 'Terms and Conditions for use of TicketsInRome services and website.',
};

export default function TermsAndConditions() {
    return (
        <main className="min-h-screen bg-cream selection:bg-olive selection:text-white">
            <Navbar />

            <div className="container mx-auto px-4 py-24 max-w-4xl">
                <h1 className="text-4xl md:text-5xl font-black text-gray-900 mb-8 tracking-tight">Terms and Conditions</h1>

                <div className="prose prose-lg prose-emerald text-gray-600 max-w-none space-y-8">
                    <p className="lead text-xl text-gray-800 font-medium">
                        Terms and Conditions refer to the use of the Tickets in Rome website (the “Service”). Please carefully read these “Terms and Conditions,” as they include crucial information regarding your legal rights and duties. This is the agreement between Tickets in Rome (“us”, “we”, or “our”) and Its Users/Clients.
                    </p>

                    <p>
                        Acceptance and compliance with these Terms are required for access to and use of the Service. All visitors, users, and others who access or use the Service are bound by these Terms. You may not use the Service if you disagree with any aspect of the terms.
                    </p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">1. DEFINITIONS</h3>
                    <ul className="list-disc pl-5 space-y-1">
                        <li><strong>Terms and Conditions of Use:</strong> Refers to the terms that influence the user’s usage of this website.</li>
                        <li><strong>Services:</strong> The functions, devices, programs, information, and other tour services available through this website.</li>
                        <li><strong>User/Client:</strong> Any individual who visits and/or uses this website.</li>
                        <li><strong>Website (Site):</strong> Refers to <a href="https://ticketsinrome.com" className="text-emerald-700 font-bold hover:underline">ticketsinrome.com</a> and any links available within the website; excludes external websites not owned or controlled by Tickets in Rome.</li>
                        <li><strong>Material/s:</strong> Physical material and items contained on this site, such as HTML, products, data, images, maps, and videos.</li>
                        <li><strong>Content:</strong> The messages, information, text, and other material that are part of the website.</li>
                    </ul>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">2. YOUR RELATION WITH TICKETS IN ROME</h3>
                    <p>When you make a reservation with “Tickets in Rome,” it means that you have the authority to agree and accept these terms on behalf of yourself. These terms constitute the complete agreement between you and Us. We hold the right to make changes to these terms at any time. Adjustments take effect once published on the website. Continued use of the site implies approval of any revisions.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">3. OWNERSHIP (INTELLECTUAL PROPERTY RIGHTS)</h3>
                    <p>Tickets in Rome grants a limited, non-exclusive right of access for non-commercial, informative personal use. All materials are protected by copyright and trademark rights owned by Tickets in Rome. No material can be copied, modified, reproduced, or transmitted in any form without prior written consent from Tickets in Rome. We specifically prohibit users from posting materials that infringe on the intellectual property rights of third parties.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">4. COPYRIGHT VIOLATION CLAIMS</h3>
                    <p>If you believe your work has been reproduced on this website in violation of your copyright, please submit:</p>
                    <ul className="list-disc pl-5 space-y-1">
                        <li>A physical or digital signature of the copyright owner/representative.</li>
                        <li>A description and location of the copyrighted work on our site.</li>
                        <li>A statement confirming the information is accurate and the use is unauthorized.</li>
                    </ul>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">5. OTHER WEBSITE’S LINKS</h3>
                    <p>Our Service may contain links to third-party websites not owned by Tickets in Rome. We have no control over, and assume no responsibility for, the content or practices of any third-party sites. You acknowledge that Tickets in Rome shall not be liable for any damage or loss caused by your reliance on such external content.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">6. RESPONSIBILITY OF THE USER</h3>
                    <p>The user promises to protect Tickets in Rome from any third-party claim, action, loss, or damage (including legal expenses) arising from the user’s conduct, violation of these terms, or infringement of third-party rights.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">7. INDEMNITY</h3>
                    <p>You agree to defend and hold harmless Tickets in Rome and its directors, employees, and agents from any claims of defamation, damages, or liabilities arising from (a) your access/use of services, (b) violation of rules, or (c) violation of third-party provider rights.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">8. SERVICE VALIDITY & MODIFICATIONS</h3>
                    <p>Services are only valid for the days and hours shown on <a href="https://ticketsinrome.com" className="text-emerald-700 font-bold hover:underline">ticketsinrome.com</a>. For modifications, contact us at <a href="tel:+393514199425" className="text-emerald-700 font-bold hover:underline">+39 351 419 9425</a> or email <a href="mailto:support@ticketsinrome.com" className="text-emerald-700 font-bold hover:underline">support@ticketsinrome.com</a>. We reserve the right to cancel, alter, or replace any tour services booked via our site at any time for any reason.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">9. REFUNDS AND CANCELLATION</h3>
                    <p>To review our Refunds and Cancellation Policy, visit: <a href="/cancellation-policy" className="text-emerald-700 font-bold hover:underline">https://ticketsinrome.com/cancellation-policy/</a></p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">10. PRICING POLICY</h3>
                    <p>Tour prices are fixed at the time of booking. However, if expenses rise due to government action or sudden museum ticket increases, Tickets in Rome reserves the right to notify you of price adjustments. Tours must be paid in full at the time of booking to lock in the stated price.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">11. OUR RESPONSIBILITIES</h3>
                    <p>Tickets in Rome does not own or manage aircraft, accommodation, or restaurants. We are not liable for illness, injury, or death resulting from the performance of these third-party facilities. We accept no liability for theft, mechanical malfunction, acts of war/terrorism, weather conditions, or any cause beyond our direct control.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">12. TERMINATION</h3>
                    <p>We reserve the right to cancel or suspend your access to our Service or your account at any time, without warning, for any reason—including violation of these Terms. Upon termination, your right to use the Service ceases immediately.</p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">13. GENERAL PROVISIONS</h3>
                    <ul className="list-disc pl-5 space-y-1">
                        <li><strong>Governing Law:</strong> These Terms are governed by the laws of Italy.</li>
                        <li><strong>Assignment:</strong> Tickets in Rome may assign its rights under this agreement without limitation; users may not do so without our express approval.</li>
                        <li><strong>Entire Agreement:</strong> These terms and our Privacy Policy form the complete legally enforceable agreement.</li>
                        <li><strong>Languages:</strong> This agreement is published in English. Any translations provided are for convenience only; the English version is the legally binding document.</li>
                    </ul>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">14. PRIVACY</h3>
                    <p>The Privacy Policy and Terms and Conditions are integrated. By adopting these terms, you also adopt the Privacy Policy found here: <a href="/privacy-policy" className="text-emerald-700 font-bold hover:underline">https://ticketsinrome.com/privacy-policy/</a></p>

                    <h3 className="text-2xl font-bold text-gray-900 mt-12">15. CONTACTS</h3>
                    <p>The Tickets in Rome team is ready to assist you. Reach us at:</p>
                    <ul className="list-none pl-0 space-y-2">
                        <li><strong>Email:</strong> <a href="mailto:support@ticketsinrome.com" className="text-emerald-700 font-bold hover:underline">support@ticketsinrome.com</a></li>
                        <li><strong>Phone:</strong> <a href="tel:+393514199425" className="text-emerald-700 font-bold hover:underline">+39 351 419 9425</a></li>
                    </ul>
                </div>
            </div>

            <Footer />
        </main>
    );
}
