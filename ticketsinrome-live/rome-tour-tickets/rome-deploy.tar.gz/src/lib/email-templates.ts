export function generateCustomerEmail(
  siteId: string,
  data: {
    name: string;
    tourTitle: string;
    date: string;
    time: string;
    guests: string;
    adults: string;
    students: string;
    youths: string;
    orderId: string;
    pin: string; // Internal PIN for security
    totalAmount: number;
    metadata: any;
  }
) {
  const isWonders = siteId === 'wondersofrome';
  const brandColor = isWonders ? '#1e3a8a' : '#047857'; // Blue vs Green
  const brandName = isWonders ? 'Wonders of Rome' : 'Tickets in Rome';
  const supportPhone = '+1 555-0199'; // Agency Support
  const providerPhone = '+39 06 445 0734'; // Tours About (Example)

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; color: #333; line-height: 1.6; margin: 0; padding: 0; background-color: #f4f4f5; }
        .container { max-width: 600px; margin: 0 auto; background: #ffffff; }
        .header { background-color: #10b981; color: white; padding: 20px; text-align: center; } /* Green Banner */
        .header h1 { margin: 0; font-size: 24px; text-transform: uppercase; letter-spacing: 1px; }
        .pin-box { background: rgba(255,255,255,0.2); padding: 10px; margin-top: 10px; border-radius: 4px; font-family: monospace; }
        .alert-box { background-color: #fff7ed; border-l-4 border-orange-500; color: #9a3412; padding: 15px; margin: 20px; }
        .section { padding: 20px; border-bottom: 1px solid #e4e4e7; }
        .section-title { font-size: 14px; color: #6b7280; text-transform: uppercase; font-weight: bold; margin-bottom: 10px; }
        .logistics-box { background-color: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #cbd5e1; }
        .footer { background-color: #f4f4f5; padding: 20px; text-align: center; font-size: 12px; color: #71717a; }
        .btn { display: inline-block; background: ${brandColor}; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold; }
      </style>
    </head>
    <body>
      <div class="container">
        <!-- A. Header & Status -->
        <div class="header">
          <h1>Booking Confirmed!</h1>
          <div class="pin-box">
            Order Ref: ${data.orderId.slice(-8).toUpperCase()} | PIN: ${data.pin}
            <div style="font-size: 11px; margin-top: 5px;">Keep this PIN secret. It acts as your password.</div>
          </div>
        </div>

        <!-- B. Crucial Action Box -->
        <div class="alert-box">
          <h3 style="margin-top:0; color: #c2410c;">⚠️ Action Required: Collect Physical Tickets</h3>
          <p style="margin: 0;"><strong>This voucher is NOT your ticket.</strong></p>
          <ul style="margin-top: 10px; padding-left: 20px;">
            <li><strong>Where:</strong> Exchange this voucher at the meeting point described below.</li>
            <li><strong>When:</strong> At least 15 minutes before start time (${data.time}).</li>
          </ul>
        </div>

        <!-- C. Activity Snapshot -->
        <div class="section">
          <div class="section-title">Activity Details</div>
          <h2 style="margin: 0 0 5px 0; color: ${brandColor};">${data.tourTitle}</h2>
          <p style="margin: 0;"><strong>Date:</strong> ${data.date} @ ${data.time}</p>
          <p style="margin: 0;"><strong>Guests:</strong> ${data.guests} (Adults: ${data.adults}, Child: ${data.students})</p>
          <p style="margin: 0;"><strong>Provider:</strong> Tours About | <strong>Language:</strong> English</p>
          ${data.metadata.addOns && JSON.parse(data.metadata.addOns).length > 0 ?
      `<p style="margin-top: 10px; font-size: 13px;"><strong>Extras:</strong> ${JSON.parse(data.metadata.addOns).map((a: any) => a.name).join(', ')}</p>` : ''}
        </div>

        <!-- D. On The Day (Logistics) -->
        <div class="section">
          <div class="section-title">On The Day</div>
          <div class="logistics-box">
            <p><strong>📍 Meeting Point:</strong> <span style="color: ${brandColor}">${data.metadata.meetingPoint || 'See your booking confirmation for details'}</span></p>
            <p><strong>👀 Visual Cue:</strong> Look for staff holding a <strong>WHITE FLAG</strong> saying "ENJOY ROME".</p>
            <p><strong>⏰ Arrival Time:</strong> 15 mins prior (Strictly).</p>
            <p><a href="https://maps.google.com" style="color: ${brandColor}; text-decoration: underline;">Open in Google Maps</a></p>
          </div>
        </div>

        <!-- E. Preparation -->
        <div class="section">
          <div class="section-title">Preparation</div>
          <p><strong>📱 App Required:</strong> Download "POP GUIDE" Audio App.</p>
          <p><strong>🎒 What to bring:</strong></p>
          <ul style="margin-top: 5px; padding-left: 20px;">
            <li>Passport/ID (Mandatory for security).</li>
            <li>Headphones (for audio guide).</li>
            <li>Comfortable shoes.</li>
          </ul>
        </div>

        <!-- F. Contact -->
        <div class="footer">
          <p><strong>Questions about the tour?</strong> Call Provider: ${providerPhone}</p>
          <p><strong>Questions about payment?</strong> Call Us: ${supportPhone}</p>
          <p>&copy; ${new Date().getFullYear()} ${brandName}. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

export function generateAdminEmail(
  siteId: string,
  data: {
    name: string;
    email: string;
    phone: string;
    tourTitle: string;
    tourSlug: string;
    date: string;
    time: string;
    guests: string;
    adults: string;
    students: string;
    orderId: string;
    pin: string;
    totalAmount: number;
    metadata: any;
  }
) {
  // Financials Calculation
  const totalCharge = data.totalAmount;
  const supplierRate = totalCharge * 0.70; // Example: 70% to supplier
  const netProfit = totalCharge - supplierRate;

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: monospace; color: #333; }
        .container { max-width: 800px; margin: 0 auto; border: 1px solid #ccc; padding: 20px; }
        h2 { border-bottom: 2px solid #333; padding-bottom: 5px; }
        .section { margin-bottom: 20px; }
        .table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .table th { background-color: #f2f2f2; }
        .tag { display: inline-block; padding: 2px 5px; font-size: 11px; font-weight: bold; border-radius: 3px; }
        .tag-green { background: #dcfce7; color: #166534; }
        .tag-red { background: #fee2e2; color: #991b1b; }
      </style>
    </head>
    <body>
      <div class="container">
        
        <!-- A. Booking Overview -->
        <div class="section">
          <h2>A. Booking Overview</h2>
          <p><strong>Status:</strong> <span class="tag tag-green">[CONFIRMED - PAID]</span></p>
          <p><strong>Booking Ref:</strong> ${data.orderId}</p>
          <p><strong>Internal PIN:</strong> <span style="background: #ffeb3b; padding: 0 5px;">${data.pin}</span> (Verify if customer calls)</p>
        </div>

        <!-- B. Supplier Manifest -->
        <div class="section">
          <h2>B. Supplier Manifest Data</h2>
          <p><strong>Product:</strong> ${data.tourTitle} (Slug: ${data.tourSlug})</p>
          <p><strong>Supplier:</strong> Tours About (Default)</p>
          <p><strong>Site Origin:</strong> ${siteId}</p>
          <p><strong>Voucher Status:</strong> <span class="tag tag-green">Sent to Customer ✅</span></p>
        </div>

        <!-- C. Customer Details -->
        <div class="section">
          <h2>C. Customer Details</h2>
          <p><strong>Name:</strong> ${data.name}</p>
          <p><strong>Contact:</strong> ${data.email} | ${data.phone}</p>
          <p><strong>Pax:</strong> ${data.guests} Total (${data.adults} Adults, ${data.students} Child)</p>
          ${data.metadata.addOns ? `<p><strong>Extras:</strong> ${data.metadata.addOns}</p>` : ''}
          ${data.metadata.pickupRequired === 'yes' ? `<p><strong>Pickup:</strong> Required at ${data.metadata.hotelName}</p>` : ''}
        </div>

        <!-- D. Financials -->
        <div class="section">
          <h2>D. Financials</h2>
          <table class="table">
            <tr>
              <th>Item</th>
              <th>Amount</th>
              <th>Notes</th>
            </tr>
            <tr>
              <td>Total Charge</td>
              <td>€${totalCharge.toFixed(2)}</td>
              <td>Stripe ID: ${data.orderId}</td>
            </tr>
            <tr>
              <td>Supplier Net Rate</td>
              <td>€${supplierRate.toFixed(2)}</td>
              <td>Est. Payable to Supplier</td>
            </tr>
            <tr style="background: #ecfdf5; font-weight: bold;">
              <td>Net Profit</td>
              <td>€${netProfit.toFixed(2)}</td>
              <td>Agency Revenue</td>
            </tr>
          </table>
        </div>

        <!-- E. Operational Timeline -->
        <div class="section">
          <h2>E. Operational Timeline</h2>
          <p>[x] Booking Created (${new Date().toLocaleString()})</p>
          <p>[x] Confirmation Email Sent</p>
          <p>[ ] Action: Send SMS reminder 24h before (Scheduled)</p>
          <p>[ ] Action: Post-trip review request</p>
        </div>

      </div>
    </body>
    </html>
  `;
}
