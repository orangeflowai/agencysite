module.exports = {
    apps: [{
        name: 'wondersofrome',
        script: 'npm',
        args: 'start',
        cwd: '/var/www/wondersofrome',
        env: {
            PORT: 3001,
            NODE_ENV: 'production'
        }
    }]
};
