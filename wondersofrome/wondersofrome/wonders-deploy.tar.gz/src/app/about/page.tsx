import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { MessageCircle, Mail, MapPin, Phone, Star, Users, History, Ticket } from 'lucide-react';
import Image from "next/image";

export default function AboutPage() {
    return (
        <main className="min-h-screen bg-cream selection:bg-olive selection:text-white">
            <Navbar />

            {/* Hero Section */}
            <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
                <div className="absolute inset-0 bg-[url('/colosseum-bg.jpg')] bg-cover bg-center opacity-10 grayscale" />
                <div className="container mx-auto px-4 relative z-10">
                    <div className="max-w-4xl mx-auto text-center">
                        <span className="inline-block px-4 py-1.5 rounded-full bg-sky-100 text-sky-700 text-sm font-bold uppercase tracking-widest mb-6">
                            Our Story
                        </span>
                        <h1 className="text-4xl md:text-6xl lg:text-7xl font-black text-gray-900 leading-tight mb-8">
                            Unlocking Rome, <br />
                            <span className="text-sky-600">One Story at a Time</span>
                        </h1>
                        <p className="text-xl text-gray-600 leading-relaxed font-medium">
                            We're a group of Rome-obsessed locals who believe every ancient stone has a secret worth sharing.
                        </p>
                    </div>
                </div>
            </section>

            {/* Core Narrative */}
            <section className="py-20 bg-white">
                <div className="container mx-auto px-4">
                    <div className="max-w-3xl mx-auto">
                        <div className="prose prose-lg prose-sky mx-auto text-gray-700 font-medium leading-relaxed space-y-8">
                            <p className="text-2xl font-bold text-gray-900 italic">
                                "Gladiators once fought right here... and one of them probably complained about the traffic on the Via Sacra." 😄
                            </p>

                            <p>
                                That's the kind of magic we chase every day at <strong>Wonders of Rome</strong>.
                            </p>

                            <p>
                                We're not just tour operators—we're a bunch of Rome-obsessed locals who can't stop geeking out over this city. Our guides? They're the real deal: licensed historians, art lovers, food fanatics, and professional storytellers who grew up dodging tourists on scooters and sneaking gelato after school. They live and breathe Rome, and they want to share its wild, wonderful secrets with you.
                            </p>

                            <div className="bg-sky-50 p-8 rounded-2xl border-l-4 border-sky-600 my-12">
                                <h3 className="text-xl font-bold text-sky-900 mb-4">How it Started</h3>
                                <p className="mb-0">
                                    Back in the day (okay, not that far back), a few of us got tired of seeing visitors rush through the Vatican lines, snap a quick selfie at the Trevi Fountain, and miss the real soul of the Eternal City. So we said: "Enough chaos. Let's make Rome feel like an adventure again."
                                </p>
                            </div>

                            <p>
                                We teamed up with official partners to grab those elusive skip-the-line tickets, early-morning slots, and underground access that most people only dream about. We crafted tours that feel personal—whether you're in a small group laughing over gladiator gossip, on a private journey with your family, or chasing hidden gems in Trastevere at sunset.
                            </p>

                            <p>
                                Today, over <strong>50,000 travelers</strong> have joined us, given us a shiny <strong>4.9/5 average rating</strong>, and left with stories they'll tell for years.
                            </p>
                        </div>
                    </div>
                </div>
            </section>

            {/* Our Promise */}
            <section className="py-24 bg-cream overflow-hidden">
                <div className="container mx-auto px-4">
                    <div className="max-w-5xl mx-auto">
                        <h2 className="text-3xl lg:text-4xl font-black text-gray-900 text-center mb-16">Our Promise to You</h2>
                        <div className="grid md:grid-cols-3 gap-8">
                            <div className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                                <div className="w-14 h-14 bg-sky-100 rounded-2xl flex items-center justify-center mb-6">
                                    <History className="text-sky-600 w-8 h-8" />
                                </div>
                                <h3 className="text-xl font-bold text-gray-900 mb-4">No Boring Lectures</h3>
                                <p className="text-gray-600">Just fun, fascinating stories that bring 2,800 years of history to life in a way you'll actually remember.</p>
                            </div>

                            <div className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                                <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center mb-6">
                                    <Ticket className="text-emerald-600 w-8 h-8" />
                                </div>
                                <h3 className="text-xl font-bold text-gray-900 mb-4">Zero Stress</h3>
                                <p className="text-gray-600">We handle the lines, the crowds, and the "where do we meet?" panic. Your only job is to enjoy the view.</p>
                            </div>

                            <div className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                                <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center mb-6">
                                    <Users className="text-amber-600 w-8 h-8" />
                                </div>
                                <h3 className="text-xl font-bold text-gray-900 mb-4">Memories that Stick</h3>
                                <p className="text-gray-600">You'll leave feeling like you didn't just visit Rome—you lived a little piece of its vibrant soul.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Contact & CTA */}
            <section className="py-24 bg-white">
                <div className="container mx-auto px-4 text-center">
                    <div className="max-w-3xl mx-auto bg-gray-900 text-white p-12 lg:p-16 rounded-[3rem] shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-sky-600/20 blur-3xl rounded-full translate-x-1/2 -translate-y-1/2" />
                        <h2 className="text-3xl md:text-4xl font-black mb-6 relative z-10">Ready to unlock the Eternal City?</h2>
                        <p className="text-gray-400 mb-10 text-lg relative z-10">Browse our tours or ping us on WhatsApp—we're always up for a chat about Rome's next great adventure.</p>

                        <div className="grid sm:grid-cols-2 gap-6 mb-12 relative z-10">
                            <a href="https://wa.me/393514199425" className="flex items-center justify-center gap-3 bg-emerald-600 hover:bg-emerald-700 text-white py-4 px-8 rounded-2xl font-bold transition-all transform hover:scale-[1.02]">
                                <MessageCircle size={24} />
                                WhatsApp Chat
                            </a>
                            <Link href="/" className="flex items-center justify-center gap-3 bg-white hover:bg-gray-100 text-gray-900 py-4 px-8 rounded-2xl font-bold transition-all transform hover:scale-[1.02]">
                                Browse Tours
                            </Link>
                        </div>

                        <div className="flex flex-wrap justify-center gap-8 text-sm text-gray-400 pt-8 border-t border-white/10 relative z-10">
                            <div className="flex items-center gap-2">
                                <MapPin size={16} className="text-sky-500" />
                                Via Tunisi 43, 00192 Rome, Italy
                            </div>
                            <div className="flex items-center gap-2">
                                <Mail size={16} className="text-sky-500" />
                                info@wondersofrome.com
                            </div>
                            <div className="flex items-center gap-2">
                                <Phone size={16} className="text-sky-500" />
                                +39 351 419 9425
                            </div>
                        </div>
                    </div>

                    <p className="mt-12 text-sm font-bold text-gray-400 uppercase tracking-widest">Wonders Of Rome.</p>
                </div>
            </section>

            <Footer />
        </main>
    );
}
