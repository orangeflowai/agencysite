'use client';

import { useState, useEffect, useMemo } from 'react';
import { Calendar, User, CheckCircle, Loader2, Info, Users, Clock, AlertTriangle, Star, Minus, Plus, ChevronRight, ShoppingCart } from 'lucide-react';
import { loadStripe, Stripe } from '@stripe/stripe-js';
import GuestDetailsModal, { GuestDetail } from './GuestDetailsModal';
import Image from 'next/image';
import SmartCalendar from './ui/SmartCalendar';
import { format } from 'date-fns';
import { useSite } from '@/components/SiteProvider';
import { useCart } from '@/context/CartContext';

// Site-specific Stripe publishable keys
const PUBLISHABLE_KEYS: Record<string, string> = {
    'rome-tour-tickets': process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY_ROME || process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '',
    'wondersofrome': process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY_WONDERS || process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '',
};

interface GuestType {
    name: string;
    price: number;
    description?: string;
}

interface BookingWidgetProps {
    tour: {
        _id: string;
        title: string;
        price: number; // Base price
        slug: { current: string };
        mainImage?: any;
        guestTypes?: GuestType[];
        category?: string;
    };
}

interface TimeSlot {
    time: string;
    available_slots: number;
}

export default function BookingWidget({ tour }: BookingWidgetProps) {
    const site = useSite();
    const { addToCart } = useCart();
    const siteId = site?.slug?.current || process.env.NEXT_PUBLIC_SITE_ID || 'wondersofrome';

    // Initialize Stripe with site-specific key
    const stripePromise = useMemo(() => {
        const key = PUBLISHABLE_KEYS[siteId] || PUBLISHABLE_KEYS['wondersofrome'];
        if (!key) {
            console.error('Stripe publishable key not configured for site:', siteId);
            return null;
        }
        return loadStripe(key);
    }, [siteId]);

    // Dynamic Ticket Counts
    const [counts, setCounts] = useState<Record<string, number>>({});

    // Initialize counts with 1 for the first guest type (usually Adult)
    useEffect(() => {
        if (tour.guestTypes && tour.guestTypes.length > 0) {
            const initialCounts: Record<string, number> = {};
            tour.guestTypes.forEach((gt, idx) => {
                initialCounts[gt.name] = idx === 0 ? 1 : 0;
            });
            setCounts(initialCounts);
        } else {
            // Default if no guest types defined
            setCounts({ 'Adult': 1 });
        }
    }, [tour.guestTypes]);

    const [selectedDate, setSelectedDate] = useState('');
    const [selectedTime, setSelectedTime] = useState('');

    const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([]);
    const [loadingAvailability, setLoadingAvailability] = useState(false);

    // Checkout State
    const [checkingOut, setCheckingOut] = useState(false);
    const [showGuestModal, setShowGuestModal] = useState(false);

    // Derived State
    const totalGuests = Object.values(counts || {}).reduce((sum, count) => sum + (count || 0), 0);

    const totalPrice = useMemo(() => {
        if (tour.guestTypes && tour.guestTypes.length > 0) {
            return tour.guestTypes.reduce((sum, gt) => sum + (counts[gt.name] || 0) * gt.price, 0);
        }
        return totalGuests * tour.price;
    }, [counts, tour.guestTypes, tour.price, totalGuests]);

    const activeSlot = timeSlots.find(s => s.time === selectedTime);

    // Check availability when date changes
    useEffect(() => {
        if (!selectedDate) {
            setTimeSlots([]);
            return;
        }

        async function check() {
            setLoadingAvailability(true);
            setTimeSlots([]);
            setSelectedTime('');
            try {
                const res = await fetch(`/api/availability?slug=${tour.slug.current}&date=${selectedDate}`);
                const data = await res.json();
                setTimeSlots(data.slots || []);
            } catch (error) {
                console.error("Availability check failed", error);
            } finally {
                setLoadingAvailability(false);
            }
        }
        check();
    }, [selectedDate, tour.slug.current]);

    const handleAddToCart = () => {
        if (!selectedDate) {
            alert('Please select a date first');
            return;
        }
        if (!selectedTime) {
            alert('Please select a time');
            return;
        }

        const available = activeSlot?.available_slots || 0;
        if (available < totalGuests) {
            alert(`Sorry, only ${available} spots left for this time.`);
            return;
        }

        // Add to cart
        addToCart({
            id: `${tour._id}-${selectedDate}-${selectedTime}-${Date.now()}`,
            tourId: tour._id,
            tourTitle: tour.title,
            tourSlug: tour.slug.current,
            date: selectedDate,
            time: selectedTime,
            guestCounts: counts,
            price: totalPrice,
            image: tour.mainImage ? urlFor(tour.mainImage).url() : undefined,
        });

        alert('Added to cart! You can continue shopping or proceed to checkout.');
    };

    const handleInitialClick = () => {
        if (!selectedDate) {
            alert('Please select a date first');
            return;
        }
        if (!selectedTime) {
            alert('Please select a time');
            return;
        }

        const available = activeSlot?.available_slots || 0;
        if (available < totalGuests) {
            alert(`Sorry, only ${available} spots left for this time.`);
            return;
        }

        if (totalGuests > 1) {
            setShowGuestModal(true);
        } else {
            processCheckout([]);
        }
    };

    const handleGuestDetailsSubmit = (details: GuestDetail[]) => {
        setShowGuestModal(false);
        processCheckout(details);
    };

    const processCheckout = async (details: GuestDetail[]) => {
        const bookingData = {
            tour: {
                _id: tour._id,
                title: tour.title,
                slug: tour.slug,
                price: tour.price,
                guestTypes: tour.guestTypes,
                mainImage: tour.mainImage,
                category: tour.category,
            },
            date: selectedDate,
            time: selectedTime,
            guestCounts: counts,
            totalPrice,
            guestDetails: details,
        };

        const encodedData = encodeURIComponent(JSON.stringify(bookingData));
        window.location.href = `/checkout?data=${encodedData}`;
    };

    // Helper for Stepper
    const Stepper = ({ name, value, min = 0, max = 50 }: { name: string, value: number, min?: number, max?: number }) => (
        <div className="flex items-center gap-3">
            <button
                onClick={() => setCounts(prev => ({ ...prev, [name]: Math.max(min, (prev[name] || 0) - 1) }))}
                disabled={value <= min}
                className="w-10 h-10 rounded-xl border border-gray-200 flex items-center justify-center text-gray-400 hover:bg-gray-50 hover:text-gray-900 disabled:opacity-30 disabled:cursor-not-allowed transition-all active:scale-95 shadow-sm"
            >
                <Minus size={16} />
            </button>
            <span className="w-6 text-center font-black text-gray-900 text-lg">{value}</span>
            <button
                onClick={() => setCounts(prev => ({ ...prev, [name]: Math.min(max, (prev[name] || 0) + 1) }))}
                disabled={value >= max}
                className="w-10 h-10 rounded-xl border border-gray-200 flex items-center justify-center text-sky-600 hover:bg-sky-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all active:scale-95 shadow-sm"
            >
                <Plus size={16} />
            </button>
        </div>
    );

    return (
        <div className="space-y-4">
            <div className="bg-white rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.08)] border border-gray-100 overflow-hidden">

                <GuestDetailsModal
                    isOpen={showGuestModal}
                    onClose={() => setShowGuestModal(false)}
                    onSubmit={handleGuestDetailsSubmit}
                    guestCounts={counts}
                />

                {/* Header: Title */}
                <div className="px-8 pt-8 pb-4">
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-black uppercase tracking-[0.2em] text-sky-600 bg-sky-50 px-3 py-1 rounded-full">Secure Booking</span>
                        <div className="flex -space-x-2">
                            {[1, 2, 3].map(i => (
                                <div key={i} className={`w-6 h-6 rounded-full border-2 border-white bg-gray-200 overflow-hidden`}>
                                    <Image src={`https://i.pravatar.cc/100?img=${i + 10}`} width={24} height={24} alt="User" />
                                </div>
                            ))}
                        </div>
                    </div>
                    <h3 className="text-2xl font-black text-gray-950 flex items-center gap-2">
                        Book Your Experience
                    </h3>
                </div>

                {/* Date Selection */}
                <div className="p-8 pt-4 space-y-8">
                    <div>
                        <div className="flex items-center justify-between mb-4">
                            <span className="text-sm font-black uppercase tracking-widest text-gray-400">1. Select Date</span>
                            {selectedDate && <span className="text-xs font-bold text-sky-600 flex items-center gap-1"><CheckCircle size={12} /> {format(new Date(selectedDate), 'MMM dd, yyyy')}</span>}
                        </div>
                        <SmartCalendar
                            slug={tour.slug.current}
                            selectedDate={selectedDate ? new Date(selectedDate) : undefined}
                            onSelect={(d) => setSelectedDate(d ? format(d, 'yyyy-MM-dd') : '')}
                            basePrice={tour.price}
                        />
                    </div>

                    {selectedDate && (
                        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 pt-2">
                            <div className="flex items-center justify-between mb-4">
                                <span className="text-sm font-black uppercase tracking-widest text-gray-400">2. Select Time</span>
                                {selectedTime && <span className="text-xs font-bold text-sky-600 flex items-center gap-1"><CheckCircle size={12} /> {selectedTime}</span>}
                            </div>

                            {loadingAvailability ? (
                                <div className="flex flex-col items-center justify-center py-10 bg-gray-50/50 rounded-2xl border-2 border-dashed border-gray-100">
                                    <Loader2 className="w-8 h-8 animate-spin text-sky-600 mb-3" />
                                    <span className="text-sm text-gray-500 font-bold uppercase tracking-widest">Scanning local times...</span>
                                </div>
                            ) : timeSlots.length > 0 ? (
                                <div className="grid grid-cols-3 gap-3">
                                    {timeSlots.map(slot => (
                                        <button
                                            key={slot.time}
                                            onClick={() => setSelectedTime(slot.time)}
                                            disabled={slot.available_slots === 0}
                                            className={`
                                                relative py-4 px-2 text-sm font-black rounded-2xl border-2 transition-all duration-300 text-center flex flex-col items-center justify-center gap-1
                                                ${selectedTime === slot.time
                                                    ? 'bg-sky-600 text-white border-sky-600 shadow-xl shadow-sky-100 scale-[1.05] z-10'
                                                    : 'bg-white text-gray-900 border-gray-100 hover:border-sky-300 hover:bg-sky-50/30'
                                                }
                                                ${slot.available_slots === 0 ? 'opacity-30 cursor-not-allowed bg-gray-50 grayscale' : ''}
                                            `}
                                        >
                                            <span className="text-base">{slot.time}</span>
                                            {slot.available_slots < 5 && slot.available_slots > 0 &&
                                                <span className={`text-[9px] font-bold uppercase ${selectedTime === slot.time ? 'text-sky-100' : 'text-rose-600'}`}>
                                                    {slot.available_slots} Left
                                                </span>
                                            }
                                        </button>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-sm text-rose-600 font-black py-6 px-4 bg-rose-50/50 rounded-2xl border-2 border-rose-100 flex flex-col items-center justify-center gap-3">
                                    <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center">
                                        <AlertTriangle size={24} className="text-rose-600" />
                                    </div>
                                    <span className="uppercase tracking-widest text-[10px]">Fully booked for this date</span>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                {/* Guests Selection */}
                <div className="px-8 py-8 bg-gray-50/50 border-t border-gray-100">
                    <div className="flex items-center justify-between mb-6">
                        <span className="text-sm font-black uppercase tracking-widest text-gray-400">3. Select Participants</span>
                        <div className="flex items-center gap-1 bg-white px-2 py-1 rounded-lg border border-gray-100 shadow-sm">
                            <Users size={12} className="text-sky-600" />
                            <span className="text-[10px] font-black text-gray-900">{totalGuests} Total</span>
                        </div>
                    </div>

                    <div className="space-y-6">
                        {tour.guestTypes && tour.guestTypes.length > 0 ? (
                            tour.guestTypes.map(gt => (
                                <div key={gt.name} className="flex items-center justify-between group">
                                    <div className="flex flex-col">
                                        <span className="text-sm font-black text-gray-950 group-hover:text-sky-600 transition-colors uppercase tracking-wide">{gt.name}</span>
                                        {gt.description && <span className="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-tight">{gt.description}</span>}
                                        <span className="text-xs font-black text-sky-600 mt-1.5 flex items-center gap-1">
                                            €{gt.price} <span className="text-[9px] text-gray-400 font-bold uppercase">/ Person</span>
                                        </span>
                                    </div>
                                    <Stepper name={gt.name} value={counts[gt.name] || 0} />
                                </div>
                            ))
                        ) : (
                            <div className="flex items-center justify-between group">
                                <div className="flex flex-col">
                                    <span className="text-sm font-black text-gray-950 group-hover:text-sky-600 transition-colors uppercase tracking-wide">Participants</span>
                                    <span className="text-xs font-black text-sky-600 mt-1.5 flex items-center gap-1">
                                        €{tour.price} <span className="text-[9px] text-gray-400 font-bold uppercase">/ Person</span>
                                    </span>
                                </div>
                                <Stepper name="Adult" value={counts['Adult'] || 0} min={1} />
                            </div>
                        )}
                    </div>
                </div>

                {/* Price Breakdown Preview */}
                <div className="px-8 py-4 bg-gray-50/80 border-t border-gray-100">
                    <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-gray-400">
                        <span>Currency</span>
                        <span>Official Price</span>
                    </div>
                    <div className="flex justify-between items-end mt-1">
                        <div className="flex items-center gap-2">
                            <div className="w-6 h-6 bg-white rounded-lg border border-gray-200 flex items-center justify-center font-black text-[10px] text-gray-900 shadow-sm">€</div>
                            <span className="text-xs font-black text-gray-900 italic">Euro (Official)</span>
                        </div>
                        <span className="text-2xl font-black text-gray-950 tracking-tighter">€{totalPrice}</span>
                    </div>
                </div>

                <div className="p-8 pt-2">
                    {/* Add to Cart Button */}
                    <button
                        onClick={handleAddToCart}
                        disabled={!selectedDate || !selectedTime || totalGuests === 0}
                        className="w-full mb-3 py-4 rounded-2xl font-black text-xs uppercase tracking-[0.2em] transition-all duration-300 transform active:scale-[0.98] border-2 border-gray-100 text-gray-400 hover:border-sky-300 hover:text-sky-600 disabled:opacity-30 flex items-center justify-center gap-3 group"
                    >
                        <ShoppingCart size={16} className="group-hover:scale-110 transition-transform" />
                        Add to Selection
                    </button>

                    <button
                        onClick={handleInitialClick}
                        disabled={checkingOut || !selectedDate || !selectedTime || totalGuests === 0}
                        className={`w-full py-5 rounded-2xl font-black text-sm uppercase tracking-[0.3em] shadow-2xl transition-all duration-300 transform active:scale-[0.97] flex items-center justify-center gap-3 ${checkingOut || !selectedDate || !selectedTime || totalGuests === 0
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : 'bg-gray-950 text-white hover:bg-sky-600 shadow-sky-100 hover:shadow-sky-300'
                            }`}
                    >
                        {checkingOut ? <Loader2 className="animate-spin" /> : <span>Confirm Booking</span>}
                        {!checkingOut && <ChevronRight size={18} />}
                    </button>

                    <div className="mt-6 pt-6 border-t border-gray-100 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="flex gap-1">
                                {[1, 2, 3, 4, 5].map(i => <Star key={i} size={10} className="fill-amber-400 text-amber-400" />)}
                            </div>
                            <span className="text-[10px] font-black text-gray-900 border-l border-gray-200 pl-3">4.9 / 5.0 Rating</span>
                        </div>
                        <div className="flex items-center gap-1.5 grayscale opacity-50">
                            <div className="w-5 h-3 bg-gray-200 rounded-sm"></div>
                            <div className="w-5 h-3 bg-gray-200 rounded-sm"></div>
                            <div className="w-5 h-3 bg-gray-200 rounded-sm"></div>
                        </div>
                    </div>
                </div>

            </div>

            <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-4 border border-white/50 flex items-center gap-4 group cursor-default">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <CheckCircle size={20} />
                </div>
                <div>
                    <h4 className="text-xs font-black text-gray-900 uppercase tracking-widest">Free Cancellation</h4>
                    <p className="text-[10px] font-bold text-gray-400 mt-0.5 tracking-tight uppercase">Full refund up to 24h before</p>
                </div>
            </div>
        </div>
    );
}

// Import urlFor for images
import { urlFor } from '@/sanity/lib/image';
