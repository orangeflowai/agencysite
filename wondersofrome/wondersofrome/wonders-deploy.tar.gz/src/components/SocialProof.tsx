
'use client';

import { Star, CheckCircle, Quote } from 'lucide-react';
import { motion } from 'framer-motion';

const reviews = [
    {
        name: "James H.",
        location: "USA",
        text: "We did the Rome in a Day tour with Sev and it was phenomenal. He was an encyclopedia of knowledge!",
        rating: 5
    },
    {
        name: "Maria G.",
        location: "UK",
        text: "Francesca made the Vatican Museums come alive. Skip-the-line access was a lifesaver.",
        rating: 5
    },
    {
        name: "Robert D.",
        location: "Australia",
        text: "The Colosseum underground was the highlight. Walking on the arena floor felt surreal.",
        rating: 5
    },
    {
        name: "Sophie Bennett",
        location: "France",
        text: "Efficient, fun, and so informative. We saw everything we wanted without the stress.",
        rating: 5
    },
    {
        name: "Alessandro R.",
        location: "Italy",
        text: "Even as a local, I learned so much from Roberta. The hidden gems tour is a must.",
        rating: 5
    },
    {
        name: "Chen Wei",
        location: "Singapore",
        text: "Totally worth it for the early morning access to the Sistine Chapel. Magical experience.",
        rating: 5
    }
];

export default function SocialProof() {
    return (
        <section className="py-24 bg-sky-900 text-white relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '30px 30px' }}></div>

            <div className="container mx-auto px-4 relative z-10 mb-16">
                <div className="flex flex-col md:flex-row items-center justify-between gap-12 text-center md:text-left">

                    {/* Left: Stats */}
                    <div className="flex-1 space-y-6">
                        <div className="inline-flex items-center space-x-2 bg-sky-800/50 px-4 py-2 rounded-full border border-sky-700/50 backdrop-blur-sm">
                            <CheckCircle size={16} className="text-sky-400" />
                            <span className="text-sm font-bold tracking-wider uppercase text-sky-100">Official Partner</span>
                        </div>
                        <h2 className="text-4xl md:text-5xl font-black leading-none tracking-tight">
                            Trusted by over <br /><span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 to-teal-200">50,000+</span> Travelers
                        </h2>
                        <div className="flex flex-col sm:flex-row items-center gap-6 justify-center md:justify-start">
                            <div className="flex items-center space-x-1">
                                {[...Array(5)].map((_, i) => (
                                    <Star key={i} size={24} className="fill-yellow-400 text-yellow-400" />
                                ))}
                            </div>
                            <span className="text-lg font-medium text-sky-100">
                                <strong className="text-white">4.9/5</strong> Average Rating
                            </span>
                        </div>
                    </div>

                    {/* Right: Logos (Static for authority) */}
                    <div className="grid grid-cols-2 gap-x-12 gap-y-8 flex-1 opacity-70 mix-blend-screen grayscale hover:grayscale-0 transition-all duration-500">
                        <div className="text-3xl font-serif italic text-center font-bold">Vogue</div>
                        <div className="text-2xl font-serif font-black uppercase tracking-widest text-center flex items-center justify-center">Traveler</div>
                        <div className="text-2xl font-sans font-bold text-center flex items-center justify-center">Lonely Planet</div>
                        <div className="text-2xl font-serif font-bold text-center flex items-center justify-center">Nat Geo</div>
                    </div>
                </div>
            </div>

            {/* Scrolling Reviews Marquee */}
            <div className="relative w-full overflow-hidden">
                {/* Gradients to fade edges */}
                <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-emerald-900 to-transparent z-10 pointer-events-none"></div>
                <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-emerald-900 to-transparent z-10 pointer-events-none"></div>

                <motion.div
                    className="flex gap-6 whitespace-nowrap pl-4"
                    animate={{ x: [0, -1000] }} // Adjust logic for seamless loop if needed, simplistic for now
                    transition={{
                        repeat: Infinity,
                        ease: "linear",
                        duration: 30,
                    }}
                >
                    {/* Double the array for seamless illusion (short-term) */}
                    {[...reviews, ...reviews, ...reviews].map((review, i) => (
                        <div key={i} className="w-[350px] bg-white/10 backdrop-blur-md border border-white/10 p-6 rounded-2xl flex-shrink-0 hover:bg-white/15 transition-colors cursor-pointer relative group">
                            <Quote className="absolute top-4 right-4 text-sky-500/20 group-hover:text-sky-400/40 transition-colors" size={40} />

                            <div className="flex items-center space-x-1 mb-3">
                                {[...Array(5)].map((_, stars) => (
                                    <Star key={stars} size={14} className="fill-yellow-400 text-yellow-400" />
                                ))}
                            </div>

                            <p className="text-sky-50 text-base font-medium leading-relaxed whitespace-normal mb-4 min-h-[48px]">
                                "{review.text}"
                            </p>

                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-sky-500 flex items-center justify-center text-xs font-bold text-white shadow-inner">
                                    {review.name.charAt(0)}
                                </div>
                                <div className="flex flex-col">
                                    <span className="text-sm font-bold text-white">{review.name}</span>
                                    <span className="text-xs text-sky-200">{review.location}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </motion.div>
            </div>
        </section>
    );
}
