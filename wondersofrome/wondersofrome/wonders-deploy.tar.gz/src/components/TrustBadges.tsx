'use client';

import { motion } from 'framer-motion';
import { Users, Star, Headphones, Sparkles } from 'lucide-react';

const badges = [
    {
        icon: Users,
        value: "100+",
        label: "Certified Guides",
        description: "Highly qualified local experts"
    },
    {
        icon: Star,
        value: "99.9%",
        label: "Happy Travelers",
        description: "Thousands of 5-star reviews"
    },
    {
        icon: Headphones,
        value: "24/7",
        label: "Customer Support",
        description: "We're always here to help"
    },
    {
        icon: Sparkles,
        value: "VIP",
        label: "Exclusive Access",
        description: "Skip-the-line everywhere"
    }
];

export default function TrustBadges() {
    return (
        <section className="py-16 bg-olive">
            <div className="container mx-auto px-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
                    {badges.map((badge, index) => (
                        <motion.div
                            key={badge.label}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                            className="text-center"
                        >
                            <div className="inline-flex items-center justify-center w-14 h-14 bg-white/10 rounded-full mb-4">
                                <badge.icon className="w-7 h-7 text-white" />
                            </div>
                            <div className="text-3xl md:text-4xl font-bold text-white mb-1">
                                {badge.value}
                            </div>
                            <div className="text-white font-semibold mb-1">
                                {badge.label}
                            </div>
                            <div className="text-white/60 text-sm hidden md:block">
                                {badge.description}
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}
