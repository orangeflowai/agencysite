
import { Mail, Bell, Facebook, Instagram, Twitter, Linkedin, Youtube } from 'lucide-react';

export default function Newsletter() {
    return (
        <div className="bg-white border-y border-gray-100 py-12">
            <div className="container mx-auto px-4">
                <div className="flex flex-col lg:flex-row items-center justify-between gap-8 max-w-7xl mx-auto">

                    {/* Left: Icon & Text */}
                    <div className="flex items-center gap-6 w-full lg:w-1/3 justify-center lg:justify-start">
                        <div className="relative">
                            <Mail size={48} strokeWidth={1} className="text-gray-300" />
                            <Bell size={24} className="absolute -bottom-2 -right-2 text-sky-600 fill-white bg-white rounded-full p-0.5" />
                        </div>
                        <div className="text-left">
                            <h3 className="text-xl font-bold text-gray-900">Get Updates & More</h3>
                            <p className="text-sm text-gray-500">Thoughtful thoughts to your inbox</p>
                        </div>
                    </div>

                    {/* Center: Input Form */}
                    <div className="w-full lg:w-1/3">
                        <div className="flex items-center w-full max-w-md mx-auto bg-gray-50 border border-gray-200 rounded-lg overflow-hidden focus-within:ring-2 focus-within:ring-emerald-500/20 transition-all shadow-sm">
                            <input
                                type="email"
                                placeholder="Your email address"
                                className="flex-grow bg-transparent px-4 py-3 text-sm text-gray-700 outline-none placeholder:text-gray-400"
                            />
                            <button className="bg-sky-800 hover:bg-sky-900 text-white text-xs font-bold uppercase tracking-widest px-6 py-4 transition-colors">
                                Subscribe
                            </button>
                        </div>
                    </div>

                    {/* Right: Social Follow */}
                    <div className="w-full lg:w-1/3 flex flex-col items-center lg:items-end gap-2">
                        <span className="text-sm font-bold text-gray-900">Follow Us</span>
                        <div className="flex gap-4">
                            {[
                                { Icon: Facebook, href: '#' },
                                { Icon: Instagram, href: '#' },
                                { Icon: Twitter, href: '#' },
                                { Icon: Youtube, href: '#' },
                                { Icon: Linkedin, href: '#' }
                            ].map(({ Icon, href }, i) => (
                                <a
                                    key={i}
                                    href={href}
                                    className="block p-2 rounded-full bg-sky-50 text-sky-700 hover:bg-sky-600 hover:text-white transition-all transform hover:-translate-y-1"
                                >
                                    <Icon size={18} />
                                </a>
                            ))}
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}
