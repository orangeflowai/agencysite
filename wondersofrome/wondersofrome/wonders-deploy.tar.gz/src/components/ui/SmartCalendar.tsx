'use client';

import { useState, useEffect } from 'react';
import { DayPicker } from 'react-day-picker';
import { format } from 'date-fns';
import { enGB } from 'date-fns/locale';
import { Loader2 } from 'lucide-react';
import 'react-day-picker/dist/style.css';

interface AvailabilityData {
    votes?: number; // repurposed for slots
    spots: number;
    price?: number;
}

interface SmartCalendarProps {
    slug?: string;
    selectedDate: Date | undefined;
    onSelect: (date: Date | undefined) => void;
    basePrice?: number;
}

export default function SmartCalendar({ slug, selectedDate, onSelect, basePrice = 0 }: SmartCalendarProps) {
    const [month, setMonth] = useState<Date>(new Date());
    const [availability, setAvailability] = useState<Record<string, AvailabilityData>>({});
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!slug) return; // Skip fetch if no slug

        async function fetchAvailability() {
            setLoading(true);
            try {
                const monthStr = format(month, 'yyyy-MM');
                const res = await fetch(`/api/availability?slug=${slug}&mode=month&date=${monthStr}`);
                if (res.ok) {
                    const data = await res.json();
                    setAvailability(data);
                }
            } catch (error) {
                console.error("Failed to fetch calendar data", error);
            } finally {
                setLoading(false);
            }
        }
        fetchAvailability();
    }, [slug, month]);

    // Custom Day Renderer
    const DayContent = (props: any) => {
        const dateStr = format(props.date, 'yyyy-MM-dd');
        const data = availability[dateStr];
        const isPast = props.date < new Date(new Date().setHours(0, 0, 0, 0));

        if (isPast) return <span className="text-gray-300">{format(props.date, 'd')}</span>;

        return (
            <div className="flex flex-col items-center justify-center p-1 w-full h-full relative group">
                <span className="text-sm font-bold">{format(props.date, 'd')}</span>
                {data ? (
                    <div className="flex flex-col items-center mt-1">
                        <span className="text-[10px] text-sky-600 font-bold">
                            €{data.price || basePrice}
                        </span>
                        <span className={`text-[9px] ${data.spots < 5 ? 'text-orange-500 font-bold' : 'text-gray-400'}`}>
                            {data.spots} left
                        </span>
                    </div>
                ) : (
                    !loading && <span className="text-[10px] text-gray-300">-</span>
                )}
            </div>
        );
    };

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 relative notranslate" translate="no">
            {loading && <div className="absolute top-4 right-4"><Loader2 className="w-4 h-4 animate-spin text-sky-600" /></div>}
            <DayPicker
                mode="single"
                selected={selectedDate}
                onSelect={onSelect}
                month={month}
                onMonthChange={setMonth}
                locale={enGB}
                components={{
                    DayContent: DayContent
                } as any}
                modifiers={{
                    available: (date) => !!availability[format(date, 'yyyy-MM-dd')]
                }}
                modifiersClassNames={{
                    selected: 'bg-sky-600 text-white hover:bg-sky-700',
                    available: 'font-medium'
                }}
                disabled={[
                    { before: new Date() }
                ]}
                className="custom-calendar"
            />
            <style jsx global>{`
                .rdp { --rdp-cell-size: 60px; --rdp-accent-color: #059669; margin: 0; }
                .rdp-day_selected { background-color: #059669; color: white; }
                .rdp-day_selected:hover { background-color: #047857; }
                .rdp-button:hover:not([disabled]):not(.rdp-day_selected) { background-color: #ecfdf5; color: #059669; }
            `}</style>
        </div>
    );
}
